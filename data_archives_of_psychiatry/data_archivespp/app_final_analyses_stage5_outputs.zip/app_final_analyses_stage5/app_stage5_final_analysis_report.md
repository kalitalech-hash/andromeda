# Etap 5 — analizy końcowe

## Dane wejściowe
Plik: `app_keywords_long_polish_semantic_4_periodized.csv`

## Zakres
- Rekordy keyword-long: 2573
- Artykuły: 684
- Unikalne pojęcia analityczne: 515
- Okresy: 2005-2009, 2010-2014, 2015-2019, 2020-2025

## Statystyki po okresach

|   analysis_period_order | analysis_period   |   n_articles |   n_article_concept_links |   mean_concepts_per_article |   median_concepts_per_article |   min_year |   max_year |   n_unique_concepts |
|------------------------:|:------------------|-------------:|--------------------------:|----------------------------:|------------------------------:|-----------:|-----------:|--------------------:|
|                       1 | 2005-2009         |          144 |                       455 |                        3.16 |                             3 |       2005 |       2009 |                 140 |
|                       2 | 2010-2014         |          161 |                       504 |                        3.13 |                             3 |       2010 |       2014 |                 151 |
|                       3 | 2015-2019         |          177 |                       585 |                        3.31 |                             3 |       2015 |       2019 |                 187 |
|                       4 | 2020-2025         |          202 |                       716 |                        3.54 |                             4 |       2020 |       2025 |                 204 |

## Top 10 pojęć ogółem

| keyword_concept_polish_analysis                |   n_articles |   share_articles_pct |
|:-----------------------------------------------|-------------:|---------------------:|
| schizofrenia i zaburzenia psychotyczne         |          236 |                34.5  |
| zaburzenia osobowości i cechy osobowości       |          154 |                22.51 |
| interwencje terapeutyczne i rehabilitacja      |          106 |                15.5  |
| choroby somatyczne i współchorobowość medyczna |           80 |                11.7  |
| trauma, PTSD i zaburzenia stresowe             |           76 |                11.11 |
| funkcjonowanie społeczne i wsparcie społeczne  |           75 |                10.96 |
| zaburzenia używania substancji i uzależnienia  |           68 |                 9.94 |
| samoocena, tożsamość i obraz siebie            |           66 |                 9.65 |
| zaburzenia odżywiania i obraz ciała            |           63 |                 9.21 |
| depresja i zaburzenia depresyjne               |           63 |                 9.21 |

## Top 10 tematów rosnących

| keyword_concept_polish_analysis                  |   articles_2005-2009 |   articles_2020-2025 |   change_share_pp_final_vs_initial |
|:-------------------------------------------------|---------------------:|---------------------:|-----------------------------------:|
| interwencje terapeutyczne i rehabilitacja        |                   12 |                   52 |                              17.41 |
| COVID-19 i pandemia                              |                    0 |                   24 |                              11.88 |
| lęk i zaburzenia lękowe                          |                   10 |                   29 |                               7.42 |
| trauma, PTSD i zaburzenia stresowe               |                   10 |                   28 |                               6.92 |
| psychologia kliniczna i koncepcje psychologiczne |                    1 |                   15 |                               6.74 |
| choroby somatyczne i współchorobowość medyczna   |                   12 |                   28 |                               5.53 |
| emocje, afekt i regulacja emocji                 |                    6 |                   19 |                               5.24 |
| technologie cyfrowe i internet                   |                    0 |                    8 |                               3.96 |
| zaburzenia używania substancji i uzależnienia    |                   10 |                   22 |                               3.95 |
| dorośli i etapy życia                            |                    0 |                    6 |                               2.97 |

## Top 10 tematów malejących

| keyword_concept_polish_analysis                 |   articles_2005-2009 |   articles_2020-2025 |   change_share_pp_final_vs_initial |
|:------------------------------------------------|---------------------:|---------------------:|-----------------------------------:|
| schizofrenia i zaburzenia psychotyczne          |                   64 |                   61 |                             -14.24 |
| zaburzenia osobowości i cechy osobowości        |                   43 |                   39 |                             -10.55 |
| zaburzenia odżywiania i obraz ciała             |                   18 |                    9 |                              -8.04 |
| depresja i zaburzenia depresyjne                |                   17 |                   12 |                              -5.87 |
| historia, pamięć i trauma zbiorowa              |                    7 |                    3 |                              -3.37 |
| działania niepożądane i bezpieczeństwo leczenia |                    4 |                    0 |                              -2.78 |
| filozofia, fenomenologia i antropologia         |                    3 |                    0 |                              -2.08 |
| metodologia badań i projekt badawczy            |                   10 |                   10 |                              -1.99 |
| psychoanaliza i podejście psychodynamiczne      |                    5 |                    3 |                              -1.98 |
| organizacja opieki psychiatrycznej              |                    4 |                    2 |                              -1.79 |

## Sieć współwystępowania
- Wszystkie krawędzie współwystępowania: 1807
- Krawędzie o wadze >= 3: 181
- Węzły w sieci filtrowanej: 51
- Wykryte społeczności/klastry: 4

## Pliki wynikowe
Główne tabele:
- `app_stage5_period_descriptives.csv`
- `app_stage5_top_concepts_overall.csv`
- `app_stage5_concept_period_counts.csv`
- `app_stage5_concept_trends_wide.csv`
- `app_stage5_rising_topics.csv`
- `app_stage5_falling_topics.csv`
- `app_stage5_emerging_topics.csv`
- `app_stage5_persistent_topics.csv`
- `app_stage5_cooccurrence_edges_weight_ge3.csv`
- `app_stage5_network_nodes.csv`
- `app_stage5_network_communities.csv`

Figury:
- `figures/fig1_articles_by_period.png`
- `figures/fig2_top20_overall.png`
- `figures/fig3_top25_period_heatmap.png`
- `figures/fig4_rising_topics.png`
- `figures/fig5_falling_topics.png`
- `figures/fig6_cooccurrence_network_top40.png`
