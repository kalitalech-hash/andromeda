# Robocza interpretacja wyników etapu 5

Analiza końcowa została przeprowadzona na finalnej warstwie `keyword-long` po polonizacji, agregacji semantycznej, audycie i podziale na okresy. Zbiór obejmował 684 artykuły, 2573 przypisań artykuł–pojęcie oraz 515 unikalnych pojęć analitycznych.

Najczęściej występujące pojęcia ogółem wskazują na dominację tematów związanych z psychopatologią, metodologią/oceną kliniczną, psychoterapią oraz głównymi grupami zaburzeń psychicznych. Analiza zmian między pierwszym i ostatnim okresem pokazuje przesunięcie akcentów w stronę tematów współczesnych, w tym problematyki pandemii COVID-19, zdrowia psychicznego, dobrostanu oraz wybranych grup diagnostycznych.

Sieć współwystępowania została zbudowana na poziomie artykułów: dwa pojęcia łączono krawędzią, jeśli wystąpiły w tym samym artykule. Do interpretacji głównej rekomendowane jest użycie sieci filtrowanej do krawędzi o wadze co najmniej 3, co ogranicza szum wynikający z jednostkowych współwystąpień.
