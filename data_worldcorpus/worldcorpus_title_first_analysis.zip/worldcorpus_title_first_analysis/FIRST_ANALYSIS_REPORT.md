# World corpus title analysis — first exploratory pass

## Input and filtering

Input file: `worldcorpus_titles_input_analysis_candidate.csv`

- Input rows: 14,898
- Residual non-research / technical records removed in this pass: 36
- Analysis v01 rows: 14,862
- Journals: 10
- Year range: 2005–2025

The filtering in this pass only removes residual technical records that survived the previous candidate screen, such as `Cover Design Credit`, `Guide for Authors`, `Notice`, front/back matter, and exact `Book review` records. It should be treated as an auditable v01 filter, not as a final exclusion policy.

## Journal size

| journal_key                            |   n_titles |   year_min |   year_max |
|:---------------------------------------|-----------:|-----------:|-----------:|
| behaviour_research_and_therapy         |       2953 |       2005 |       2025 |
| journal_consulting_clinical_psychology |       2483 |       2005 |       2025 |
| clinical_psychology_psychotherapy      |       1732 |       2005 |       2025 |
| psychotherapy_research                 |       1500 |       2005 |       2025 |
| counselling_psychotherapy_research     |       1367 |       2005 |       2025 |
| arts_in_psychotherapy                  |       1278 |       2005 |       2025 |
| psychotherapy                          |       1258 |       2005 |       2025 |
| psychology_psychotherapy_tprp          |        878 |       2005 |       2025 |
| cognitive_behaviour_therapy            |        751 |       2005 |       2025 |
| journal_psychotherapy_integration      |        662 |       2005 |       2025 |

## Period size

| analysis_period   |   n_titles |   n_journals |
|:------------------|-----------:|-------------:|
| 2005-2009         |       2917 |           10 |
| 2010-2014         |       3027 |           10 |
| 2015-2019         |       3471 |           10 |
| 2020-2025         |       5447 |           10 |

## Top thematic title terms, document frequency

The terms below are document-frequency counts: a term is counted once per title even if repeated.

| term                  |   n_articles |   pct_articles |   n_words | term_set   |
|:----------------------|-------------:|---------------:|----------:|:-----------|
| cognitive             |         1737 |         11.688 |         1 | thematic   |
| disorder              |         1706 |         11.479 |         1 | thematic   |
| anxiety               |         1263 |          8.498 |         1 | thematic   |
| depression            |         1139 |          7.664 |         1 | thematic   |
| self                  |          897 |          6.036 |         1 | thematic   |
| behavioral            |          851 |          5.726 |         1 | thematic   |
| outcome               |          777 |          5.228 |         1 | thematic   |
| change                |          726 |          4.885 |         1 | thematic   |
| symptoms              |          679 |          4.569 |         1 | thematic   |
| intervention          |          674 |          4.535 |         1 | thematic   |
| material              |          674 |          4.535 |         1 | thematic   |
| supplemental          |          670 |          4.508 |         1 | thematic   |
| supplemental material |          669 |          4.501 |         2 | thematic   |
| social                |          665 |          4.474 |         1 | thematic   |
| disorders             |          649 |          4.367 |         1 | thematic   |
| cognitive behavioral  |          634 |          4.266 |         2 | thematic   |
| alliance              |          594 |          3.997 |         1 | thematic   |
| therapeutic           |          593 |          3.99  |         1 | thematic   |
| stress                |          570 |          3.835 |         1 | thematic   |
| group                 |          554 |          3.728 |         1 | thematic   |
| training              |          537 |          3.613 |         1 | thematic   |
| therapist             |          526 |          3.539 |         1 | thematic   |
| personality           |          496 |          3.337 |         1 | thematic   |
| outcomes              |          487 |          3.277 |         1 | thematic   |
| children              |          478 |          3.216 |         1 | thematic   |
| experiences           |          472 |          3.176 |         1 | thematic   |
| practice              |          450 |          3.028 |         1 | thematic   |
| therapists            |          434 |          2.92  |         1 | thematic   |
| adolescents           |          430 |          2.893 |         1 | thematic   |
| eating                |          423 |          2.846 |         1 | thematic   |

## Top rising title terms

Rising terms are ranked by percentage-point change from 2005–2009 to 2020–2025. This is exploratory and should be audited before interpretation.

| term                  |   n_total |   pct_2005-2009 |   pct_2020-2025 |   pct_change_2005_2025 | peak_period   |
|:----------------------|----------:|----------------:|----------------:|-----------------------:|:--------------|
| supplemental          |       670 |           0.651 |           7.747 |                  7.096 | 2020-2025     |
| supplemental material |       669 |           0.651 |           7.729 |                  7.078 | 2020-2025     |
| material              |       674 |           0.72  |           7.747 |                  7.027 | 2020-2025     |
| intervention          |       674 |           2.503 |           6.077 |                  3.574 | 2020-2025     |
| experiences           |       472 |           1.817 |           4.828 |                  3.011 | 2020-2025     |
| covid                 |       149 |           0     |           2.735 |                  2.735 | 2020-2025     |
| outcomes              |       487 |           1.885 |           4.204 |                  2.319 | 2020-2025     |
| therapists            |       434 |           1.68  |           3.91  |                  2.23  | 2020-2025     |
| exploring             |       226 |           0.651 |           2.625 |                  1.974 | 2020-2025     |
| adults                |       353 |           1.474 |           3.415 |                  1.941 | 2020-2025     |
| online                |       201 |           0.446 |           2.387 |                  1.941 | 2020-2025     |
| compassion            |       155 |           0.103 |           1.928 |                  1.825 | 2020-2025     |
| emotion               |       367 |           1.337 |           3.139 |                  1.802 | 2020-2025     |
| people                |       331 |           1.268 |           3.066 |                  1.798 | 2020-2025     |
| mindfulness           |       315 |           0.754 |           2.46  |                  1.706 | 2015-2019     |
| issue information     |       132 |           0     |           1.597 |                  1.597 | 2020-2025     |
| interventions         |       352 |           1.577 |           3.121 |                  1.544 | 2020-2025     |
| symptoms              |       679 |           4.011 |           5.508 |                  1.497 | 2020-2025     |
| emotion regulation    |       167 |           0.377 |           1.873 |                  1.496 | 2020-2025     |
| regulation            |       238 |           0.857 |           2.35  |                  1.493 | 2020-2025     |
| issue                 |       199 |           0.48  |           1.964 |                  1.484 | 2020-2025     |
| students              |       222 |           0.686 |           2.148 |                  1.462 | 2020-2025     |
| alliance              |       594 |           3.12  |           4.571 |                  1.451 | 2020-2025     |
| scp                   |       117 |           0     |           1.45  |                  1.45  | 2020-2025     |
| transdiagnostic       |       160 |           0.171 |           1.616 |                  1.445 | 2020-2025     |
| pandemic              |        78 |           0     |           1.432 |                  1.432 | 2020-2025     |
| change                |       726 |           3.737 |           5.122 |                  1.385 | 2015-2019     |
| experience            |       278 |           1.028 |           2.332 |                  1.304 | 2020-2025     |
| trauma                |       318 |           1.474 |           2.735 |                  1.261 | 2020-2025     |
| information           |       202 |           0.583 |           1.836 |                  1.253 | 2015-2019     |

## Top falling title terms

| term                          |   n_total |   pct_2005-2009 |   pct_2020-2025 |   pct_change_2005_2025 | peak_period   |
|:------------------------------|----------:|----------------:|----------------:|-----------------------:|:--------------|
| compulsive                    |       253 |           3.291 |           1.138 |                 -2.153 | 2005-2009     |
| obsessive                     |       227 |           2.743 |           1.138 |                 -1.605 | 2005-2009     |
| obsessive compulsive          |       220 |           2.674 |           1.12  |                 -1.554 | 2005-2009     |
| panic                         |       147 |           2.057 |           0.514 |                 -1.543 | 2005-2009     |
| phobia                        |        93 |           1.508 |           0.147 |                 -1.361 | 2005-2009     |
| compulsive disorder           |       171 |           2.125 |           0.789 |                 -1.336 | 2005-2009     |
| obsessive compulsive disorder |       171 |           2.125 |           0.789 |                 -1.336 | 2005-2009     |
| anxious                       |       110 |           1.508 |           0.312 |                 -1.196 | 2005-2009     |
| children                      |       478 |           3.908 |           2.809 |                 -1.099 | 2005-2009     |
| social phobia                 |        61 |           1.097 |           0.055 |                 -1.042 | 2005-2009     |
| panic disorder                |       109 |           1.371 |           0.422 |                 -0.949 | 2005-2009     |
| news                          |        56 |           0.891 |           0     |                 -0.891 | 2005-2009     |
| suppression                   |        46 |           0.96  |           0.073 |                 -0.887 | 2005-2009     |
| coping                        |       161 |           1.611 |           0.753 |                 -0.858 | 2005-2009     |
| abuse                         |       114 |           1.371 |           0.514 |                 -0.857 | 2005-2009     |
| year                          |       157 |           1.44  |           0.624 |                 -0.816 | 2010-2014     |
| eating                        |       423 |           2.948 |           2.148 |                 -0.8   | 2010-2014     |
| thought                       |        48 |           0.926 |           0.129 |                 -0.797 | 2005-2009     |
| anxiety sensitivity           |       104 |           1.303 |           0.514 |                 -0.789 | 2005-2009     |
| news notes                    |        50 |           0.788 |           0     |                 -0.788 | 2005-2009     |
| posttraumatic                 |       302 |           2.605 |           1.818 |                 -0.787 | 2005-2009     |
| notes                         |        56 |           0.823 |           0.037 |                 -0.786 | 2010-2014     |
| women                         |       296 |           2.365 |           1.652 |                 -0.713 | 2005-2009     |
| stress disorder               |       269 |           2.297 |           1.597 |                 -0.7   | 2005-2009     |
| introduction                  |       109 |           1.097 |           0.404 |                 -0.693 | 2005-2009     |
| syndrome                      |        88 |           1.028 |           0.349 |                 -0.679 | 2005-2009     |
| stress                        |       570 |           4.491 |           3.819 |                 -0.672 | 2005-2009     |
| disorder                      |      1706 |          11.244 |          10.575 |                 -0.669 | 2015-2019     |
| social                        |       665 |           4.594 |           3.947 |                 -0.647 | 2010-2014     |
| primary                       |        93 |           1.028 |           0.404 |                 -0.624 | 2005-2009     |

## Rule-based thematic families, overall

These families are preliminary dictionary probes, not final semantic coding.

| family                          |   n_articles |   pct_articles |
|:--------------------------------|-------------:|---------------:|
| outcome_change_recovery         |         2292 |          15.42 |
| children_adolescents_family     |         1902 |          12.8  |
| randomized_trials_evidence      |         1889 |          12.71 |
| anxiety_fear_phobia             |         1837 |          12.36 |
| depression_and_mood             |         1750 |          11.77 |
| trauma_ptsd_stress              |         1075 |           7.23 |
| cbt_cognitive_behavioral        |         1066 |           7.17 |
| alliance_relationship_process   |          970 |           6.53 |
| couple_relationships            |          847 |           5.7  |
| training_supervision            |          766 |           5.15 |
| arts_creative_therapies         |          743 |           5    |
| digital_internet_telehealth     |          711 |           4.78 |
| eating_weight_body              |          658 |           4.43 |
| mindfulness_acceptance          |          625 |           4.21 |
| culture_diversity_identity      |          555 |           3.73 |
| mechanisms_mediation_moderation |          524 |           3.53 |
| personality                     |          515 |           3.47 |
| substance_addiction             |          497 |           3.34 |
| meta_review_synthesis           |          471 |           3.17 |
| psychosis_schizophrenia         |          440 |           2.96 |
| psychodynamic_psychoanalytic    |          357 |           2.4  |
| ocd_compulsions                 |          340 |           2.29 |
| suicide_self_harm               |          326 |           2.19 |
| covid_pandemic                  |          159 |           1.07 |

## Recommended next step

Use `worldcorpus_titles_analysis_v01.csv` for the first proper title-cleaning and term-extraction stage.

Before interpretation, review:

- `residual_nonresearch_candidates_removed_v01.csv`
- `title_terms_overall_thematic_docfreq.csv`
- `title_terms_trends_wide.csv`
- `rule_based_family_summary_by_journal.csv`
- `rule_based_family_summary_by_period.csv`

The next methodological step is to create a reviewed semantic map from high-frequency title terms and dictionary-family probes.
