# How Psychotherapy Research Describes Itself: A Title-Based Bibliometric Map of Ten International Journals, 2005–2025

**Short title:** Title-based bibliometric map of psychotherapy research  
**Target journal:** *Scientometrics*  
**Manuscript status:** Round 6 literature-grounded draft v01  
**Article type:** Original research article / bibliometric science mapping study

## Abstract

This study maps two decades of international psychotherapy and clinical psychological intervention research using article titles as a standardized layer of scholarly self-description. A corpus of 14,229 titles published between 2005 and 2025 was assembled from ten journals representing psychotherapy research, clinical intervention research, cognitive-behavioral and behavioral clinical science, psychotherapy integration, counselling research, and creative arts therapies. The initial workflow attempted to extract author-assigned keywords from public article landing pages; however, a source audit showed that author keywords were not consistently exposed in public landing-page metadata. The analysis therefore shifted to a title-based bibliometric pipeline. After quality control and removal of non-substantive and supplemental-material records, titles were coded using an auditable, non-exclusive rule-based system of 26 thematic families. The most frequent family was outcome/change/recovery (18.67% of titles), followed by anxiety/fear/phobia/panic (11.93%), children/adolescents/youth (11.55%), training/supervision/therapist development (11.19%), depression and mood (10.82%), and CBT and cognitive-behavioral therapies (9.40%). The largest increases between 2005–2009 and 2020–2025 were observed for review/meta-analysis/synthesis (+6.10 percentage points), third-wave/mindfulness/compassion (+5.25), training/supervision/therapist development (+5.04), digital/online/telehealth (+4.79), and outcome/change/recovery (+4.69). The findings suggest that title-level psychotherapy discourse has become increasingly organized not only by disorders and modalities but also by outcome evaluation, evidence synthesis, mechanisms, delivery systems, therapist development, and professional practice. The article contributes a reproducible human-in-the-loop workflow for mapping field self-description when keyword metadata are unavailable or inconsistent.

**Keywords:** psychotherapy research; bibliometrics; scientometrics; title analysis; science mapping; clinical psychology; discourse mapping; human-in-the-loop analysis

## 1. Introduction

Bibliometric and scientometric methods are increasingly used to map the development of scientific fields, identify emerging topics, and examine the organization of scholarly communication. In this tradition, fields are not only counted through publication volumes or citations; they are also mapped through the language used to describe research objects, methods, populations, and claims. Co-word analysis and related science-mapping approaches rest on the assumption that recurring words and phrases in bibliographic metadata can serve as indicators of conceptual structure and thematic organization (Callon et al., 1991; Ding et al., 2001). Contemporary tools such as bibliometrix and VOSviewer have institutionalized this logic in reproducible workflows for analyzing keywords, titles, abstracts, and other bibliographic fields (Aria & Cuccurullo, 2017; van Eck & Waltman, 2010).

Psychotherapy research offers a particularly suitable case for this type of mapping. It is a heterogeneous field that spans clinical trials, process-outcome research, therapist development, psychotherapy integration, cognitive-behavioral and third-wave approaches, counselling research, and creative arts therapies. Its discourse is shaped by multiple organizing logics: diagnostic categories, treatment modalities, mechanisms of change, patient populations, professional training, evidence synthesis, and service delivery systems. The field also has a strong history of debate about what counts as evidence, what produces change, and how therapeutic relationships and treatment models should be understood (Kazdin, 2007; Wampold & Imel, 2015).

Most bibliometric mappings of clinical or psychotherapy-related fields rely on database-supplied keywords, author keywords, abstracts, or citation networks. However, keyword metadata are not always consistently available across publishers and journals. This creates a methodological problem for longitudinal, multi-journal studies: the most intuitively attractive metadata field may be missing, inconsistent, or not exposed in public landing-page metadata. The present study began as an author-keyword mapping project, but a source audit showed that author-assigned keywords were not consistently retrievable from public article landing pages. This prompted a methodological pivot toward article titles.

Article titles are not full texts and cannot substitute for article-level content analysis. They are, however, highly standardized and consistently available. They condense what authors, editors, and journals choose to foreground as the public-facing identity of a publication. A title may name a disorder, treatment model, outcome, mechanism, population, method, or setting. At scale, titles can therefore be analyzed as a layer of scholarly self-description. The present study uses this layer to ask how international psychotherapy and clinical psychological intervention research has described itself over two decades.

### 1.1 Research questions

The study addresses four research questions:

1. What thematic families dominate the title-level self-description of psychotherapy and clinical psychological intervention research between 2005 and 2025?
2. How did the relative prominence of these thematic families change across four analytical periods?
3. How do journals differ in their title-level thematic profiles?
4. What does a title-based mapping reveal about broader shifts in psychotherapy research discourse?

## 2. Methods

### 2.1 Corpus design and journal selection

The journal set was selected purposively rather than as a strict impact-factor ranking. The aim was to construct a broad but coherent corpus covering major segments of international psychotherapy and clinical psychological intervention research. The sample included journals centrally devoted to psychotherapy research and practice, high-volume clinical intervention and clinical psychology journals, journals representing the cognitive-behavioral and behavioral clinical science tradition, journals focused on psychotherapy integration and counselling-practice links, and a journal representing creative arts therapies.

This selection strategy was designed to capture heterogeneity within psychotherapy-related research discourse rather than to claim exhaustive coverage of all psychotherapy journals. Adjacent domains such as psychoanalysis, family therapy, group psychotherapy, counselling psychology, and implementation science may require dedicated supplementary corpora.

### 2.2 Data acquisition and metadata audit

Bibliographic metadata were acquired through a Crossref-based workflow. Crossref provides open infrastructure for DOI-linked scholarly metadata and is a standard source for publication-level metadata retrieval. The workflow queried journal records by ISSN and year range, collected article-level metadata, and resolved DOI landing pages. The original pipeline attempted to extract author-assigned keywords from landing-page HTML, metadata tags, JSON-LD blocks, and visible keyword sections.

A keyword-source audit was then conducted on samples across the ten journals. The audit did not identify a consistent public HTML or metadata signal for author-assigned keywords. In the raw corpus, keyword-long files contained no usable keyword records. Therefore, the project was transferred from the author-keyword pipeline to a title-based pipeline. This decision was documented as a methodological pivot rather than treated as a silent preprocessing step.

### 2.3 Cleaning and analytical corpus

The raw bibliographic layer was preserved as an immutable source layer. Subsequent cleaning produced a title-corpus input file. Non-substantive records such as guide-for-authors records, notices, front/back matter, and other technical entries were excluded. Supplemental and supplementary material records were also removed because they represented technical metadata rather than substantive article titles. Review articles were retained, because evidence synthesis was considered part of the epistemic discourse of the field.

The final analytical corpus contained **14,229 titles** from **10 journals** covering **2005–2025**.

### 2.4 Periodization

Titles were assigned to four analytical periods:

- 2005–2009
- 2010–2014
- 2015–2019
- 2020–2025

The final period contains six years because the project scope extended through 2025.

### 2.5 Thematic family coding

A transparent rule-based thematic family system was developed and audited. The final accepted rulebook included **26 non-exclusive thematic families**. Families were grouped into broad types, including clinical-problem, therapeutic-modality, process/mechanism, outcome-evaluation, population/context, professional-context, method/measurement, delivery-system, historical-context, clinical-context, and method-epistemic categories.

Non-exclusive coding was intentional. Titles frequently combine several dimensions, such as a clinical problem, population, treatment modality, outcome, and mechanism. For example, a title may simultaneously refer to CBT, anxiety, youth, outcomes, and digital delivery.

### 2.6 Analysis

Document frequency was calculated at the title level. Period-specific percentages were calculated relative to the number of titles in each period. Journal profiles were calculated as within-journal percentages. Trends were summarized as percentage-point changes between 2005–2009 and 2020–2025. Family co-occurrence was defined as the co-presence of two thematic families in the same title.

## 3. Results

### 3.1 Corpus composition

The final title-based analytical corpus included **14,229 article titles** from ten journals. Table 1 summarizes corpus composition by journal.

**Table 1. Corpus composition by journal**

| Journal key                            |   Titles |   First year |   Last year |   % with ≥1 family |   Mean families/title |
|:---------------------------------------|---------:|-------------:|------------:|-------------------:|----------------------:|
| behaviour_research_and_therapy         |     2953 |         2005 |        2025 |              82.73 |                  1.71 |
| journal_consulting_clinical_psychology |     1996 |         2005 |        2025 |              89.68 |                  2.02 |
| clinical_psychology_psychotherapy      |     1732 |         2005 |        2025 |              86.26 |                  1.8  |
| psychotherapy_research                 |     1506 |         2005 |        2025 |              84.06 |                  1.79 |
| counselling_psychotherapy_research     |     1372 |         2005 |        2025 |              68.44 |                  1.16 |
| arts_in_psychotherapy                  |     1281 |         2005 |        2025 |              80.8  |                  1.5  |
| psychotherapy                          |     1109 |         2005 |        2025 |              76.47 |                  1.48 |
| psychology_psychotherapy_tprp          |      899 |         2005 |        2025 |              78.31 |                  1.62 |
| cognitive_behaviour_therapy            |      752 |         2005 |        2025 |              91.09 |                  1.98 |
| journal_psychotherapy_integration      |      629 |         2005 |        2025 |              66.77 |                  1.21 |

### 3.2 Dominant thematic families

The rule-based family system assigned at least one thematic family to **11,624 titles**, corresponding to **81.69%** of the corpus. Across the corpus, **23,771 title–family assignments** were generated, with a mean of **1.67 families per title**.

The most frequent thematic family was outcome/change/recovery, assigned to 2,657 titles (18.67%). Other dominant families included anxiety/fear/phobia/panic, children/adolescents/youth, training/supervision/therapist development, depression and mood, CBT and cognitive-behavioral therapies, self/identity/attachment, trauma/PTSD/stress, emotion/regulation/affect, mechanisms/mediators/moderators, alliance/process/relationship, and assessment/measurement/psychometrics.

**Table 2. Top thematic families overall**

| Family                                         | Family type          |   Titles |   % of titles |
|:-----------------------------------------------|:---------------------|---------:|--------------:|
| outcome / change / recovery                    | outcome_evaluation   |     2657 |         18.67 |
| anxiety / fear / phobia / panic                | clinical_problem     |     1697 |         11.93 |
| children / adolescents / youth                 | population_context   |     1644 |         11.55 |
| training / supervision / therapist development | professional_context |     1592 |         11.19 |
| depression and mood                            | clinical_problem     |     1539 |         10.82 |
| CBT and cognitive-behavioral therapies         | therapeutic_modality |     1337 |          9.4  |
| self / identity / attachment                   | process_mechanism    |     1255 |          8.82 |
| trauma / PTSD / stress                         | clinical_problem     |     1136 |          7.98 |
| emotion / regulation / affect                  | process_mechanism    |     1069 |          7.51 |
| mechanisms / mediators / moderators            | process_mechanism    |      989 |          6.95 |
| alliance / process / relationship              | process_mechanism    |      955 |          6.71 |
| assessment / measurement / psychometrics       | method_measurement   |      806 |          5.66 |

This distribution indicates that the title-level discourse is not organized solely around diagnostic categories. It also strongly foregrounds outcome evaluation, therapeutic process, professional development, mechanisms of change, measurement, and delivery context.

### 3.3 Longitudinal shifts

The largest increases between 2005–2009 and 2020–2025 were observed for review/meta-analysis/synthesis, third-wave/mindfulness/compassion, training/supervision/therapist development, digital/online/telehealth, and outcome/change/recovery.

**Table 3. Fastest-rising thematic families**

| family                                         | family_type          |   total |   2005-2009_pct |   2020-2025_pct |   delta_pct_last_first | status            |
|:-----------------------------------------------|:---------------------|--------:|----------------:|----------------:|-----------------------:|:------------------|
| review / meta-analysis / synthesis             | method_epistemic     |     634 |           1.535 |           7.639 |                  6.104 | persistent_rising |
| third-wave / mindfulness / compassion          | therapeutic_modality |     715 |           1.637 |           6.883 |                  5.246 | persistent_rising |
| training / supervision / therapist development | professional_context |    1592 |           7.708 |          12.751 |                  5.043 | persistent_rising |
| digital / online / telehealth                  | delivery_system      |     635 |           1.739 |           6.525 |                  4.786 | persistent_rising |
| outcome / change / recovery                    | outcome_evaluation   |    2657 |          14.666 |          19.355 |                  4.689 | persistent_rising |
| COVID-19 / pandemic                            | historical_context   |     158 |           0     |           3.143 |                  3.143 | emerging          |
| emotion / regulation / affect                  | process_mechanism    |    1069 |           6.241 |           9.031 |                  2.79  | persistent_rising |
| mechanisms / mediators / moderators            | process_mechanism    |     989 |           5.014 |           7.679 |                  2.665 | persistent_rising |
| arts / creative therapies                      | therapeutic_modality |     703 |           3.274 |           5.669 |                  2.395 | persistent_rising |
| alliance / process / relationship              | process_mechanism    |     955 |           5.218 |           6.943 |                  1.725 | persistent_rising |

The growth of review/meta-analysis/synthesis suggests increasing visibility of evidence aggregation and secondary research in the title-level discourse. The rise of third-wave/mindfulness/compassion points to the expanding prominence of newer therapeutic modalities and process targets. The growth of digital/online/telehealth reflects changing delivery systems, particularly in the later period. Training/supervision/therapist development also increased markedly, suggesting greater explicit attention to therapist competence, fidelity, supervision, and professional formation.

### 3.4 Declining or relatively declining families

Families with negative percentage-point changes should be interpreted as relatively declining shares within an expanding and diversifying discourse, not as disappearing topics. A decreasing share may reflect the emergence of additional themes rather than reduced absolute attention.

**Table 4. Families with the largest relative decreases**

| family                          | family_type          |   total |   2005-2009_pct |   2020-2025_pct |   delta_pct_last_first | status             |
|:--------------------------------|:---------------------|--------:|----------------:|----------------:|-----------------------:|:-------------------|
| anxiety / fear / phobia / panic | clinical_problem     |    1697 |          12.585 |          11.14  |                 -1.445 | persistent_falling |
| eating / body image             | clinical_problem     |     559 |           3.581 |           2.904 |                 -0.677 | persistent_stable  |
| couple / family / relationship  | population_context   |     507 |           3.854 |           3.402 |                 -0.452 | persistent_stable  |
| psychodynamic / psychoanalytic  | therapeutic_modality |     360 |           2.49  |           2.109 |                 -0.381 | persistent_stable  |
| somatic / medical comorbidity   | clinical_context     |     467 |           3.547 |           3.223 |                 -0.324 | persistent_stable  |
| personality / BPD               | clinical_problem     |     508 |           3.718 |           3.402 |                 -0.316 | persistent_stable  |
| culture / diversity / identity  | population_context   |     474 |           3.82  |           3.601 |                 -0.219 | persistent_stable  |
| substance use / addiction       | clinical_problem     |     450 |           2.353 |           2.506 |                  0.153 | persistent_stable  |

### 3.5 Journal profiles

Journal-level profiles showed substantial heterogeneity. This supports the decision to treat the corpus as a field map composed of distinct but overlapping subdomains rather than as a homogeneous psychotherapy literature.

**Table 5. Journal profiles**

| Journal key                            |   Titles | Top families (abbreviated)                                                                                                             | Distinctive families (abbreviated)                                                                                                                    |
|:---------------------------------------|---------:|:---------------------------------------------------------------------------------------------------------------------------------------|:------------------------------------------------------------------------------------------------------------------------------------------------------|
| behaviour_research_and_therapy         |     2953 | anxiety / fear / phobia / panic (26.6%); outcome / change / recovery (17.2%); depression and mood (14.2%)                              | anxiety / fear / phobia / panic (lift 2.23); eating / body image (lift 1.83); CBT and cognitive-behavioral therapies (lift 1.47)                      |
| journal_consulting_clinical_psychology |     1996 | outcome / change / recovery (28.5%); children / adolescents / youth (21.0%); depression and mood (16.4%)                               | substance use / addiction (lift 3.52); couple / family / relationship (lift 2.53); culture / diversity / identity (lift 1.97)                         |
| clinical_psychology_psychotherapy      |     1732 | outcome / change / recovery (15.0%); depression and mood (13.3%); self / identity / attachment (13.1%)                                 | personality / BPD (lift 2.44); assessment / measurement / psychometrics (lift 2.29); review / meta-analysis / synthesis (lift 2.19)                   |
| psychotherapy_research                 |     1506 | outcome / change / recovery (32.5%); training / supervision / therapist development (19.7%); alliance / process / relationship (18.7%) | psychodynamic / psychoanalytic (lift 2.91); alliance / process / relationship (lift 2.79); training / supervision / therapist development (lift 1.76) |
| counselling_psychotherapy_research     |     1372 | training / supervision / therapist development (20.1%); outcome / change / recovery (12.8%); children / adolescents / youth (11.5%)    | training / supervision / therapist development (lift 1.80); COVID-19 / pandemic (lift 1.77); implementation / services / access (lift 1.64)           |
| arts_in_psychotherapy                  |     1281 | arts / creative therapies (50.7%); children / adolescents / youth (16.6%); training / supervision / therapist development (10.3%)      | arts / creative therapies (lift 10.27); somatic / medical comorbidity (lift 1.50); children / adolescents / youth (lift 1.43)                         |
| psychotherapy                          |     1109 | outcome / change / recovery (20.7%); training / supervision / therapist development (17.9%); alliance / process / relationship (16.4%) | psychodynamic / psychoanalytic (lift 3.14); alliance / process / relationship (lift 2.45); culture / diversity / identity (lift 1.92)                 |
| psychology_psychotherapy_tprp          |      899 | self / identity / attachment (18.1%); outcome / change / recovery (14.3%); psychosis / schizophrenia (12.9%)                           | psychosis / schizophrenia (lift 5.76); self / identity / attachment (lift 2.06); third-wave / mindfulness / compassion (lift 1.97)                    |
| cognitive_behaviour_therapy            |      752 | anxiety / fear / phobia / panic (36.6%); CBT and cognitive-behavioral therapies (24.5%); outcome / change / recovery (15.8%)           | anxiety / fear / phobia / panic (lift 3.06); digital / online / telehealth (lift 3.01); COVID-19 / pandemic (lift 3.00)                               |
| journal_psychotherapy_integration      |      629 | training / supervision / therapist development (15.4%); outcome / change / recovery (11.8%); alliance / process / relationship (10.8%) | psychodynamic / psychoanalytic (lift 2.26); COVID-19 / pandemic (lift 1.72); alliance / process / relationship (lift 1.61)                            |

Full journal profiles are provided in Supplementary Table S5.

### 3.6 Co-occurrence structure

Family co-occurrence analysis identified thematic combinations that were jointly foregrounded in titles. The strongest co-occurrences connected outcome/change with clinical-problem families, therapeutic modalities, training, mechanisms, and process constructs. This suggests that titles commonly combine problem domains with evaluation, method, mechanism, or delivery markers.

## 4. Discussion

This study mapped the title-level self-description of psychotherapy and clinical psychological intervention research across ten international journals from 2005 to 2025. The results suggest a field organized by several overlapping logics. Diagnostic and problem categories such as anxiety, depression, trauma, personality, and youth remain highly visible. However, the dominant family was outcome/change/recovery, indicating that the discourse foregrounds evaluation and change as central organizing concerns. This aligns with the long-standing centrality of outcome research in psychotherapy and clinical intervention science.

At the same time, the strongest longitudinal shifts point beyond a disorder-centered model. Evidence synthesis, third-wave and mindfulness/compassion approaches, therapist training and supervision, digital and telehealth delivery, mechanisms and mediators, emotion regulation, and alliance/process all increased in relative visibility. These changes suggest that psychotherapy research increasingly describes itself through questions of synthesis, delivery, process, competence, and mechanism.

The rise of review/meta-analysis/synthesis is especially important for a scientometric interpretation. It indicates not merely a thematic change but an epistemic shift: the field increasingly marks itself through aggregation, synthesis, and evidence organization. This is consistent with a broader movement in clinical research toward systematic reviews, meta-analysis, evidence hierarchies, and cumulative knowledge structures.

The growth of digital/online/telehealth and COVID-19/pandemic categories reflects changes in delivery conditions and historical context. The COVID-19 family is expectedly concentrated in the final period, but digital and online delivery were already visible before the pandemic and then accelerated. This suggests that digitalization is not reducible to the pandemic, even if the pandemic likely intensified its salience.

The increase in training/supervision/therapist development indicates a professionalization axis within the field. Titles increasingly mark therapist factors, competence, fidelity, supervision, and training. This trend may reflect growing attention to implementation, dissemination, treatment quality, and the translation of research-supported interventions into practice.

Finally, the persistence and growth of alliance/process/relationship, emotion/regulation/affect, self/identity/attachment, and mechanisms/mediators/moderators suggest a process-oriented discourse. These families point to a field concerned not only with whether interventions work but also with how, for whom, through whom, and under what conditions they work. This connects directly to long-standing psychotherapy research questions about mechanisms of change and the therapeutic relationship.

### 4.1 Methodological contribution

The study also contributes a methodological lesson. The initial keyword-based approach failed because author-assigned keywords were not consistently exposed in public metadata. Rather than treating this as a technical inconvenience, the project documented the failure and transferred the corpus to a title-based pipeline. This makes the workflow relevant to bibliometric studies in fields where keyword metadata are sparse, inconsistent, or publisher-dependent.

The title-based approach is not a substitute for abstract or full-text analysis. Its strength lies in comparability and availability. Titles form a stable, public-facing metadata layer across journals and years. They are well suited for mapping field self-description, particularly when the research question concerns what authors and journals choose to foreground.

### 4.2 Limitations

Several limitations should be emphasized. First, the corpus was purposively selected and does not exhaust all psychotherapy-related journals. Important adjacent domains, including psychoanalysis, family therapy, group psychotherapy, counselling psychology, and implementation science, may require dedicated supplementary corpora.

Second, article titles are compressed representations. They do not capture all constructs, methods, or interpretations present in abstracts or full texts. The results should therefore be interpreted as title-level self-description rather than full-content discourse.

Third, family coding was rule-based. This makes the analysis auditable and reproducible, but it cannot capture all semantic nuance. Some terms are polysemous, and some families are intentionally broad. The non-exclusive coding system mitigates this problem by allowing titles to belong to several families, but expert interpretation remains necessary.

Fourth, relative declines should not be read as disappearance. Percentage changes reflect shifts in share within an expanding and diversifying corpus.

### 4.3 Conclusion

Across two decades, psychotherapy and clinical psychological intervention research increasingly describes itself through a combination of outcomes, synthesis, mechanisms, delivery systems, professional development, and process-oriented constructs. Classical clinical topics and modalities remain central, but the title-level discourse has expanded toward a more reflexive, evidence-organizing, delivery-aware, and mechanism-oriented field. The study demonstrates how a transparent human-in-the-loop title-based bibliometric workflow can map the public self-description of a research field when author-keyword metadata are unavailable or inconsistent.

## Data and code availability

The project is structured as an auditable, layered workflow. Derived data tables, thematic rulebooks, and analysis outputs are intended for deposit in the project repository. Raw scrape outputs should be preserved as immutable source data, while cleaned title-corpus, family assignments, tables, and figures should be deposited as reproducible analytical layers.

## Acknowledgments and AI-assisted research support

Bibliometric data preparation, semantic family normalization, workflow design, and draft generation were supported by the research agent Andromeda Nowicka (v0.2), a human-in-the-loop computational bibliometrics system developed under the supervision of Lech Kalita. The agent was used as a research support tool and is not claimed as an independent scholarly author. All analytical decisions require human validation and responsibility.

## References

- Aria, M., & Cuccurullo, C. (2017). bibliometrix: An R-tool for comprehensive science mapping analysis. Journal of Informetrics, 11(4), 959–975. https://doi.org/10.1016/j.joi.2017.08.007
- Callon, M., Courtial, J. P., & Laville, F. (1991). Co-word analysis as a tool for describing the network of interactions between basic and technological research: The case of polymer chemistry. Scientometrics, 22(1), 155–205. https://doi.org/10.1007/BF02019280
- Crossref. (2026). Crossref REST API documentation. https://www.crossref.org/documentation/retrieve-metadata/rest-api/
- Ding, Y., Chowdhury, G. G., & Foo, S. (2001). Bibliometric cartography of information retrieval research by using co-word analysis. Information Processing & Management, 37(6), 817–842. https://doi.org/10.1016/S0306-4573(00)00051-0
- Kazdin, A. E. (2007). Mediators and mechanisms of change in psychotherapy research. Annual Review of Clinical Psychology, 3, 1–27. https://doi.org/10.1146/annurev.clinpsy.3.022806.091432
- Koo, M. (2023). An analysis of reporting practices in the top 100 cited health and medicine-related bibliometric studies from 2019 to 2021 based on a proposed guidelines. Heliyon, 9(6), e16865. https://doi.org/10.1016/j.heliyon.2023.e16865
- Springer Nature. (2026). Scientometrics: Aims and scope. https://link.springer.com/journal/11192/aims-and-scope
- van Eck, N. J., & Waltman, L. (2010). Software survey: VOSviewer, a computer program for bibliometric mapping. Scientometrics, 84, 523–538. https://doi.org/10.1007/s11192-009-0146-3
- VOSviewer. (2026). VOSviewer: Visualizing scientific landscapes. https://www.vosviewer.com/
- Wampold, B. E., & Imel, Z. E. (2015). The great psychotherapy debate: The evidence for what makes psychotherapy work (2nd ed.). Routledge.
