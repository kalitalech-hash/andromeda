# World corpus Round 6 — literature-grounded manuscript

This package contains the Round 6 literature-grounded manuscript draft for the world psychotherapy title corpus project.

## Main files

- `andromeda_worldcorpus_round6_manuscript_literature_grounded_v01.docx`
- `andromeda_worldcorpus_round6_manuscript_literature_grounded_v01.md`
- `docs/reference_matrix_round6.csv`
- `docs/submission_memo_round6.md`
- `docs/round7_transition_plan.md`

## Status

Round 6 adds literature grounding and submission-oriented framing to the Round 5 draft. It does not yet finalize reference-manager formatting or journal-specific submission formatting. Round 7 should verify references, tailor style to *Scientometrics*, and prepare cover letter / supplementary materials.

## Core counts

- Titles: 14,229
- Journals: 10
- Years: 2005–2025
- Thematic families: 26
