# Round 7 transition plan

Round 6 produced a literature-grounded manuscript draft. Round 7 should focus on submission tailoring and reference verification.

## Tasks

1. Verify all references manually in Zotero or another reference manager.
2. Add DOI metadata where missing.
3. Decide final target: Scientometrics first.
4. Check author guidelines: word limit, reference style, figure/table rules, supplementary material policy.
5. Convert tables into journal-style Word tables or move selected tables to supplementary materials.
6. Replace Markdown-style figure/table callouts with final manuscript callouts.
7. Prepare cover letter.
8. Prepare repository README and data/code availability statement.

## Suggested main-text tables

- Table 1: Corpus composition by journal
- Table 2: Thematic family rulebook, abbreviated
- Table 3: Top families and period trends
- Table 4: Journal profiles, abbreviated

## Suggested main-text figures

- Figure 3: Family × period heatmap
- Figure 4: Journal × family heatmap
- Figure 5: Rising families
- Figure 6: Family co-occurrence top pairs

Full tables and detailed rulebook can be supplementary.
