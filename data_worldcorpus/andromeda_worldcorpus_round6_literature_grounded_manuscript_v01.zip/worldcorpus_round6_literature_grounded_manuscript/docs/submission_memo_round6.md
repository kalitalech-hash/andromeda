# Round 6 submission memo

## Recommended target

Scientometrics remains the recommended first target because the manuscript is a quantitative science-mapping study of scholarly field self-description. The psychotherapy content is substantive, but the strongest methodological contribution is the auditable title-based bibliometric workflow and the documented pivot from unavailable keyword metadata to a standardized title layer.

## Core argument

The article should not be framed as a technical pipeline paper alone. The main claim is that title-level metadata reveal how psychotherapy research publicly self-describes itself over two decades: increasingly through outcomes, evidence synthesis, mechanisms, delivery systems, therapist development, and process-oriented constructs, alongside persistent disorder and modality categories.

## Risk management

Potential reviewer concerns:

1. Why titles rather than abstracts or full text?
   - Answer: comparability and availability; titles are a standardized self-description layer, not a substitute for full text.

2. Why these ten journals?
   - Answer: purposive, stratified field-map sample, not exhaustive ranking.

3. Why rule-based families?
   - Answer: transparent, auditable, reproducible; non-exclusive coding fits title structure.

4. Are reviews a topic or document type?
   - Answer: retained as method-epistemic discourse because evidence synthesis is itself a visible form of field self-description.

5. Why no keywords?
   - Answer: keyword-source audit demonstrated inconsistent public availability; this is a documented metadata limitation and part of the methodological contribution.
