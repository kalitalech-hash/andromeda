# World corpus Phase 2 — family audit pack v01

## Source

`worldcorpus_titles_analysis_v02.csv`

## Corpus

- Titles: 14,229
- Families: 26
- Family assignments: 23,771
- Titles with at least one family: 11,624 (81.69%)
- Unassigned titles: 2,605
- Titles with 3+ families assigned: 3,394

## Main files

- `family_assignment_summary.csv`
- `family_assignments_long_v01.csv`
- `family_audit_samples_v01.csv`
- `family_audit_priority_samples_v01.csv`
- `multi_family_conflict_titles.csv`
- `unassigned_titles_sample.csv`
- `unassigned_titles_all.csv`
- `family_cooccurrence_edges_v01.csv`
- `family_period_counts_wide.csv`
- `family_rulebook_v01.md`
- `AUDIT_INSTRUCTIONS.md`
- `phase2_next_steps.md`

## How to use

Start with `family_audit_priority_samples_v01.csv`. Fill in `audit_decision` and `audit_notes` for problematic cases. The audit results will be used to produce `family_rulebook_v02` and rerun the family coding in round 2.
