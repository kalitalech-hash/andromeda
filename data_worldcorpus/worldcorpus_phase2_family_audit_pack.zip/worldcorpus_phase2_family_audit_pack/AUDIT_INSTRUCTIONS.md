# Family audit instructions v01

## Purpose

The current family coding is exploratory. The goal of this audit is to identify:

1. over-broad rules,
2. missing concepts,
3. false positives,
4. families that should be split,
5. families that should be merged,
6. families that should be retyped as clinical, process, method, population or delivery categories.

## Recommended audit decisions

Use the `audit_decision` column in `family_audit_samples_v01.csv` or `family_audit_priority_samples_v01.csv`.

Suggested values:

```text
keep
false_positive
too_broad
split_needed
merge_needed
rename_needed
unclear
```

## Recommended workflow

Start with:

```text
family_audit_priority_samples_v01.csv
```

This file contains samples from families most likely to need correction.

Then inspect:

```text
multi_family_conflict_titles.csv
unassigned_titles_sample.csv
```

The first reveals overly broad overlap. The second reveals missing families or terms.

## High-priority questions

1. Is `outcome / change / recovery` too broad?
2. Should `children / adolescents / youth` be separated from `family/parents/school`?
3. Is `training / supervision / therapist development` inflated by generic `therapist`?
4. Should `self / identity / attachment` be split into self/identity and attachment/mentalization?
5. Should `mechanisms / mediators / moderators` be classified as method/process rather than topic?
6. Is `review / meta-analysis / synthesis` a valid epistemic family? Current decision: yes, reviews stay as discourse.
7. Are `implementation / services / access` and `digital / online / telehealth` conceptually distinct enough?
