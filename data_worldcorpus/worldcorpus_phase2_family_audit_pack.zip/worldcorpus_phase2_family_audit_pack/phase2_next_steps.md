# Phase 2 next steps

## Current objective

Move from exploratory round 1 outputs to an audited family map suitable for trend and journal-profile analysis.

## Recommended sequence

1. Review `family_assignment_summary.csv`.
2. Audit `family_audit_priority_samples_v01.csv`.
3. Inspect `multi_family_conflict_titles.csv`.
4. Inspect `unassigned_titles_sample.csv`.
5. Decide corrections to the family rulebook.
6. Produce `family_rulebook_v02.md`.
7. Re-run family coding as `round2`.
8. Generate final tables:
   - family × period trends,
   - journal × family profiles,
   - rising/emerging/persistent/falling families,
   - family co-occurrence network.

## Expected outputs of round2

```text
round2_title_family_assignments_long.csv
round2_family_overall.csv
round2_family_period_trends_wide.csv
round2_family_by_journal_pct_wide.csv
round2_family_cooccurrence_edges.csv
round2_report.md
```
