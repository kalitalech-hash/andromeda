# Andromeda Nowicka — World Psychotherapy Corpus

## Full research report, Phase 1–3

**Status:** working research report  
**Agent:** Andromeda Nowicka v0.2  
**Controller:** Lech Kalita  
**Project:** title-based bibliometric discourse mapping of international psychotherapy and clinical-psychology journals  
**Corpus years:** 2005–2025  
**Current analytical corpus:** 14,229 titles  
**Current date of report:** 2026-05-19

---

## 1. Executive summary

This report documents the complete work conducted so far on the international psychotherapy corpus: from the initial idea of scraping author keywords, through the construction of a full bibliographic corpus, the failure of public landing-page keyword extraction, the methodological pivot to title-based discourse mapping, and the completion of three analytical rounds.

The project began with the intention of extending a previously tested keyword-based bibliometric pipeline to a set of ten international journals related to psychotherapy, clinical psychological interventions, CBT, integration, counselling, and creative therapies. A Crossref-based scraper was developed iteratively. Early test runs revealed pagination limits and HTTP timeout issues; these were corrected through subsequent scraper versions. The final raw bibliographic scrape produced approximately sixteen thousand article-level records, later cleaned to a stable analytical title corpus.

The keyword-pipeline did not recover usable author-keyword data. A dedicated source audit showed no consistent public HTML metadata signal for author-assigned keywords across sampled landing pages. Rather than treating this as a failure, the project was transferred to the title-pipeline. Article titles were defined as standardized, consistently available indicators of article self-presentation. This decision is methodologically narrower than full-text discourse analysis, but it provides a reproducible and comparable corpus across all ten journals.

After QA and cleaning, the current analytical corpus contains **14,229 article titles** from **10 journals**, covering **2005–2025**. A rule-based, auditable family coding system with **26 thematic families** was developed, audited, accepted, and used for Round 2 and Round 3 analyses. The family coding assigned at least one family to **11,624 titles (81.69%)**, producing **23,771 title–family assignments**.

Round 3 generated article-ready outputs: **9 tables**, **7 figures**, draft Methods and Results sections, figure captions, and a package of underlying data files.

---

## 2. Initial project aim

The initial aim was to build a large comparative corpus of international psychotherapy-related journals and analyze author-assigned keywords using the standard Andromeda pipeline:

```text
Crossref / DOI / landing pages
→ metadata and keywords
→ QA and deduplication
→ keyword normalization
→ semantic mapping
→ periodization
→ trends, profiles and co-occurrence
```

The project was designed as the international counterpart to earlier work on Polish psychotherapy and psychiatry journals. The working expectation was that author keywords could be obtained from article landing pages or machine-readable metadata.

---

## 3. Journal selection rationale

The journal set was selected purposively and stratified by field segment. It was not intended as an absolute bibliometric ranking of “the ten most important psychotherapy journals.” The goal was to construct a broad but coherent sample of international psychotherapy and clinical psychological intervention discourse.

The ten journals cover five complementary segments:

1. **Core psychotherapy research and practice:**  
   *Psychotherapy Research*, *Psychotherapy*

2. **Clinical psychological intervention and clinical psychology:**  
   *Journal of Consulting and Clinical Psychology*, *Clinical Psychology & Psychotherapy*, *Psychology and Psychotherapy: Theory, Research and Practice*

3. **CBT and behavioral clinical science:**  
   *Behaviour Research and Therapy*, *Cognitive Behaviour Therapy*

4. **Integration, counselling and practice links:**  
   *Journal of Psychotherapy Integration*, *Counselling and Psychotherapy Research*

5. **Creative and expressive therapies:**  
   *The Arts in Psychotherapy*

The corpus therefore represents a heterogeneous field map rather than a complete census of all psychotherapy-adjacent journals. Important adjacent domains such as psychoanalysis, family therapy, group psychotherapy, implementation science or body psychotherapy may require dedicated supplementary corpora.

---

## 4. Data acquisition and scraper development

A model scraper was developed around the following logic:

```text
Crossref search by ISSN and year range
→ article DOI and metadata
→ DOI landing page resolution
→ extraction attempt from HTML/meta/JSON-LD
→ articles.csv, keywords_long.csv, scrape_log.csv
```

The scraper went through several iterations:

| Version | Main function | Key issue or improvement |
|---|---|---|
| v01 | initial model scraper | Crossref query returned no records in practice |
| v03 | removed fragile Crossref `select`, improved diagnostics | Crossref stage began working |
| v04 | offset-based Crossref pagination | solved the apparent 200-record limit |
| v05 | retry wrapper and split timeout control | reduced hanging requests and improved stability |

An important early diagnostic was that the scraper appeared to return exactly around 200 records per journal. This was traced to incomplete Crossref pagination: approximately 100 records per ISSN variant. The offset-based version corrected this and allowed full journal-scale retrieval.

The full v05 run was long-running but successful at the bibliographic level.

---

## 5. Keyword extraction failure and source audit

The full raw scrape produced a large article-level corpus but **zero usable keyword records**. This prompted a dedicated keyword-source audit across sampled landing pages from the ten journals.

The audit looked for signals such as:

```text
citation_keywords
dc.subject
article:tag
JSON-LD keywords/about
visible keyword sections
HTML classes or IDs containing keyword markers
```

The audit result was negative: no consistent public landing-page signal for author-assigned keywords was detected. Therefore, the project could not proceed as a standard author-keyword analysis.

This was recorded as a methodological finding rather than an operational failure. It shows a difference between bibliographic discoverability through DOI metadata and the public availability of author-keyword metadata on landing pages.

---

## 6. Methodological pivot: from keyword-pipeline to title-pipeline

After the keyword audit, the project was transferred to a title-based pipeline. The new analytical object became the article title, interpreted as a standardized and consistently available indicator of article self-presentation.

Recommended framing:

> The international corpus was initially processed through the author-keyword pipeline. A source audit showed that author-assigned keywords were not consistently exposed in public landing-page metadata. Therefore, the comparative thematic analysis was conducted on article titles, treated as standardized indicators of article self-presentation.

Important limitation:

> This is not a full-text discourse analysis and not an author-keyword analysis. It is a title-based bibliometric discourse map.

The title-pipeline is narrower than a full-text approach but has three advantages:

1. titles are consistently available across journals and years;
2. titles are highly selective self-presentational signals;
3. title-level analysis is reproducible and auditable across heterogeneous publishers.

---

## 7. Canonical data layer and QA

The working canonical input became:

```text
worldcorpus_titles_input.csv
```

Initial QA showed:

| Measure | Value |
|---|---:|
| Rows | 15,979 |
| Journals | 10 |
| Years | 2005–2025 |
| Unique article IDs | 15,979 |
| Unique DOI | 15,979 |
| Duplicate article IDs | 0 |
| Duplicate DOI | 0 |
| Missing titles | 0 |
| Missing years | 0 |
| Keyword records | 0 |
| Abstract coverage | 23.49% |

The file was accepted as a valid bibliographic/title corpus, but not as a keyword corpus.

---

## 8. Cleaning decisions

The first QA pass identified non-substantive and technical records, including:

```text
Book review
Guide for Authors
Notice
Inside front cover / Editorial board
New Books of Potential Interest
Correction / Corrigendum / Erratum
Comment / Reply / Letter
```

A conservative candidate analytical layer was produced:

```text
worldcorpus_titles_input_analysis_candidate.csv
```

This contained **14,898 titles**.

Next, a specific artefact was removed:

```text
Supplemental material / Supplementary material
```

This step excluded **669 records**, producing:

```text
worldcorpus_titles_analysis_v02.csv
```

with **14,229 titles**.

Review articles were explicitly retained as part of the discourse.

---

## 9. Round 1: exploratory title analysis

Round 1 used exploratory term extraction and preliminary rule-based families. It confirmed that the title corpus was interpretable and that major thematic families emerged coherently.

Initial dominant families included:

```text
outcome / change / recovery
anxiety / fear / phobia / panic
children / adolescents / youth
training / supervision / therapist development
depression and mood
CBT and cognitive-behavioral therapies
self / identity / attachment
trauma / PTSD / stress
emotion / regulation / affect
mechanisms / mediators / moderators
```

Round 1 also revealed strong growth in:

```text
review / meta-analysis / synthesis
third-wave / mindfulness / compassion
digital / online / telehealth
training / supervision
outcome / change / recovery
COVID-19 / pandemic
emotion regulation
mechanisms / mediators / moderators
```

The main function of Round 1 was exploratory: it showed that the title-pipeline could produce interpretable results and helped define families for audit.

---

## 10. Phase 2 family audit

A family audit pack was prepared with:

```text
family_assignment_summary.csv
family_assignments_long_v01.csv
family_audit_samples_v01.csv
family_audit_priority_samples_v01.csv
multi_family_conflict_titles.csv
unassigned_titles_sample.csv
family_rulebook_v01.md
AUDIT_INSTRUCTIONS.md
```

The audit pack showed:

| Measure | Value |
|---|---:|
| Titles | 14,229 |
| Families | 26 |
| Family assignments | 23,771 |
| Titles with at least one family | 11,624 |
| Titles without family | 2,605 |
| Titles with 3+ families | 3,394 |
| Audit sample rows | 3,380 |
| Priority audit rows | 1,300 |

The researcher reviewed the audit logic and accepted the family rulebook without requested changes. The rulebook was therefore frozen as v02.

---

## 11. Round 2: stable family analysis

Round 2 used the accepted family rulebook v02.

Main counts:

| Measure | Value |
|---|---:|
| Titles analyzed | 14,229 |
| Journals | 10 |
| Years | 2005–2025 |
| Families | 26 |
| Family assignments | 23,771 |
| Titles with ≥1 family | 11,624 |
| % titles with ≥1 family | 81.69 |
| Mean families per title | 1.67 |
| Median families per title | 2.0 |

### 11.1 Dominant families overall

| family                                         | family_type          |   n_titles |   pct_titles |
|:-----------------------------------------------|:---------------------|-----------:|-------------:|
| outcome / change / recovery                    | outcome_evaluation   |       2657 |        18.67 |
| anxiety / fear / phobia / panic                | clinical_problem     |       1697 |        11.93 |
| children / adolescents / youth                 | population_context   |       1644 |        11.55 |
| training / supervision / therapist development | professional_context |       1592 |        11.19 |
| depression and mood                            | clinical_problem     |       1539 |        10.82 |
| CBT and cognitive-behavioral therapies         | therapeutic_modality |       1337 |         9.4  |
| self / identity / attachment                   | process_mechanism    |       1255 |         8.82 |
| trauma / PTSD / stress                         | clinical_problem     |       1136 |         7.98 |
| emotion / regulation / affect                  | process_mechanism    |       1069 |         7.51 |
| mechanisms / mediators / moderators            | process_mechanism    |        989 |         6.95 |
| alliance / process / relationship              | process_mechanism    |        955 |         6.71 |
| assessment / measurement / psychometrics       | method_measurement   |        806 |         5.66 |
| third-wave / mindfulness / compassion          | therapeutic_modality |        715 |         5.02 |
| arts / creative therapies                      | therapeutic_modality |        703 |         4.94 |
| digital / online / telehealth                  | delivery_system      |        635 |         4.46 |

### 11.2 Period descriptives

| analysis_period   |   n_titles |   n_journals |   n_with_family |   mean_families_per_title |   median_families_per_title |   pct_with_family |
|:------------------|-----------:|-------------:|----------------:|--------------------------:|----------------------------:|------------------:|
| 2005-2009         |       2932 |           10 |            2242 |                      1.39 |                           1 |             76.47 |
| 2010-2014         |       2974 |           10 |            2432 |                      1.66 |                           2 |             81.78 |
| 2015-2019         |       3296 |           10 |            2700 |                      1.72 |                           2 |             81.92 |
| 2020-2025         |       5027 |           10 |            4250 |                      1.81 |                           2 |             84.54 |

### 11.3 Journal descriptives

| journal_key                            |   n_titles |   year_min |   year_max |   pct_with_family |   mean_families_per_title |
|:---------------------------------------|-----------:|-----------:|-----------:|------------------:|--------------------------:|
| behaviour_research_and_therapy         |       2953 |       2005 |       2025 |             82.73 |                      1.71 |
| journal_consulting_clinical_psychology |       1996 |       2005 |       2025 |             89.68 |                      2.02 |
| clinical_psychology_psychotherapy      |       1732 |       2005 |       2025 |             86.26 |                      1.8  |
| psychotherapy_research                 |       1506 |       2005 |       2025 |             84.06 |                      1.79 |
| counselling_psychotherapy_research     |       1372 |       2005 |       2025 |             68.44 |                      1.16 |
| arts_in_psychotherapy                  |       1281 |       2005 |       2025 |             80.8  |                      1.5  |
| psychotherapy                          |       1109 |       2005 |       2025 |             76.47 |                      1.48 |
| psychology_psychotherapy_tprp          |        899 |       2005 |       2025 |             78.31 |                      1.62 |
| cognitive_behaviour_therapy            |        752 |       2005 |       2025 |             91.09 |                      1.98 |
| journal_psychotherapy_integration      |        629 |       2005 |       2025 |             66.77 |                      1.21 |

### 11.4 Fastest-rising families

| family                                         | family_type          |   total |   2005-2009_pct |   2020-2025_pct |   delta_pct_last_first | status            |
|:-----------------------------------------------|:---------------------|--------:|----------------:|----------------:|-----------------------:|:------------------|
| review / meta-analysis / synthesis             | method_epistemic     |     634 |           1.535 |           7.639 |                  6.104 | persistent_rising |
| third-wave / mindfulness / compassion          | therapeutic_modality |     715 |           1.637 |           6.883 |                  5.246 | persistent_rising |
| training / supervision / therapist development | professional_context |    1592 |           7.708 |          12.751 |                  5.043 | persistent_rising |
| digital / online / telehealth                  | delivery_system      |     635 |           1.739 |           6.525 |                  4.786 | persistent_rising |
| outcome / change / recovery                    | outcome_evaluation   |    2657 |          14.666 |          19.355 |                  4.689 | persistent_rising |
| COVID-19 / pandemic                            | historical_context   |     158 |           0     |           3.143 |                  3.143 | emerging          |
| emotion / regulation / affect                  | process_mechanism    |    1069 |           6.241 |           9.031 |                  2.79  | persistent_rising |
| mechanisms / mediators / moderators            | process_mechanism    |     989 |           5.014 |           7.679 |                  2.665 | persistent_rising |
| arts / creative therapies                      | therapeutic_modality |     703 |           3.274 |           5.669 |                  2.395 | persistent_rising |
| alliance / process / relationship              | process_mechanism    |     955 |           5.218 |           6.943 |                  1.725 | persistent_rising |
| implementation / services / access             | delivery_system      |     606 |           3.854 |           5.132 |                  1.278 | persistent_rising |
| depression and mood                            | clinical_problem     |    1539 |           9.754 |          11.02  |                  1.266 | persistent_rising |

### 11.5 Fastest-falling families

| family                                   | family_type          |   total |   2005-2009_pct |   2020-2025_pct |   delta_pct_last_first | status             |
|:-----------------------------------------|:---------------------|--------:|----------------:|----------------:|-----------------------:|:-------------------|
| anxiety / fear / phobia / panic          | clinical_problem     |    1697 |          12.585 |          11.14  |                 -1.445 | persistent_falling |
| eating / body image                      | clinical_problem     |     559 |           3.581 |           2.904 |                 -0.677 | persistent_stable  |
| couple / family / relationship           | population_context   |     507 |           3.854 |           3.402 |                 -0.452 | persistent_stable  |
| psychodynamic / psychoanalytic           | therapeutic_modality |     360 |           2.49  |           2.109 |                 -0.381 | persistent_stable  |
| somatic / medical comorbidity            | clinical_context     |     467 |           3.547 |           3.223 |                 -0.324 | persistent_stable  |
| personality / BPD                        | clinical_problem     |     508 |           3.718 |           3.402 |                 -0.316 | persistent_stable  |
| culture / diversity / identity           | population_context   |     474 |           3.82  |           3.601 |                 -0.219 | persistent_stable  |
| substance use / addiction                | clinical_problem     |     450 |           2.353 |           2.506 |                  0.153 | persistent_stable  |
| children / adolescents / youth           | population_context   |    1644 |          11.562 |          11.796 |                  0.234 | persistent_stable  |
| psychosis / schizophrenia                | clinical_problem     |     319 |           1.842 |           2.288 |                  0.446 | persistent_stable  |
| trauma / PTSD / stress                   | clinical_problem     |    1136 |           8.22  |           8.733 |                  0.513 | persistent_stable  |
| assessment / measurement / psychometrics | method_measurement   |     806 |           5.559 |           6.107 |                  0.548 | persistent_stable  |

### 11.6 Strongest family co-occurrences

| source                                 | target                                         |   weight |   jaccard |
|:---------------------------------------|:-----------------------------------------------|---------:|----------:|
| mechanisms / mediators / moderators    | outcome / change / recovery                    |      471 |    0.1483 |
| CBT and cognitive-behavioral therapies | outcome / change / recovery                    |      426 |    0.1194 |
| depression and mood                    | outcome / change / recovery                    |      376 |    0.0984 |
| CBT and cognitive-behavioral therapies | anxiety / fear / phobia / panic                |      339 |    0.1258 |
| anxiety / fear / phobia / panic        | outcome / change / recovery                    |      332 |    0.0825 |
| children / adolescents / youth         | couple / family / relationship                 |      329 |    0.1806 |
| children / adolescents / youth         | outcome / change / recovery                    |      310 |    0.0777 |
| outcome / change / recovery            | training / supervision / therapist development |      308 |    0.0782 |
| CBT and cognitive-behavioral therapies | depression and mood                            |      306 |    0.1191 |
| anxiety / fear / phobia / panic        | depression and mood                            |      303 |    0.1033 |
| alliance / process / relationship      | outcome / change / recovery                    |      300 |    0.0906 |
| outcome / change / recovery            | self / identity / attachment                   |      234 |    0.0636 |

---

## 12. Round 3: article-ready outputs

Round 3 converted the stable Round 2 analysis into publication-oriented artifacts.

Produced outputs:

| Output type | Count |
|---|---:|
| Tables | 9 |
| Figures | 7 |

### 12.1 Tables generated

```text
table1_corpus_composition_by_journal.csv
table2_thematic_family_rulebook.csv
table3_top20_families_overall.csv
table4_family_trends_by_period.csv
table5_journal_profiles.csv
table6_rising_families.csv
table6_falling_families.csv
table6_emerging_families.csv
table6_persistent_families.csv
```

### 12.2 Figures generated

```text
fig1_corpus_size_by_journal.png
fig2_corpus_size_by_period.png
fig3_family_by_period_heatmap_top20.png
fig4_journal_by_family_heatmap_top15.png
fig5_rising_family_trends.png
fig6_family_cooccurrence_top20.png
fig7_family_type_distribution.png
```

### 12.3 Draft text generated

```text
draft_methods_round3.md
draft_results_round3.md
figure_captions.md
ROUND3_OUTPUT_INDEX.md
```

---

## 13. Interpretation so far

The emerging interpretation is that the international title-level discourse of psychotherapy and clinical psychological intervention research is organized around several simultaneous axes:

1. **Outcome and evaluation:** outcome/change/recovery is the largest family and continues to grow.
2. **Clinical problem categories:** anxiety, depression, trauma, personality, eating, substance use and psychosis remain visible.
3. **Therapeutic modality:** CBT remains central, while third-wave/mindfulness/compassion approaches rise strongly.
4. **Process and mechanism:** alliance, mechanisms, emotion regulation and self/attachment are prominent.
5. **Professionalization:** training, supervision and therapist development are highly visible and increasing.
6. **Delivery systems:** digital/online/telehealth rises sharply.
7. **Epistemic consolidation:** review/meta-analysis/synthesis grows strongly, indicating increasing evidence-synthesis activity.
8. **Historical shock:** COVID-19 appears as a clear emerging final-period family.

The corpus does not show a field organized only around disorders or modalities. It shows a heterogeneous field in which titles increasingly foreground evaluation, mechanisms, training, delivery, synthesis and contextualization.

---

## 14. Key methodological decisions

| Decision | Rationale |
|---|---|
| Use Crossref as bibliographic index | DOI metadata provided scalable article discovery |
| Preserve raw data as immutable layer | Auditability and reproducibility |
| Abandon public HTML keyword scraping | Source audit showed no stable keyword signals |
| Pivot to titles | Titles were consistently available across journals |
| Remove supplemental material records | Technical artefact, especially visible in later years |
| Retain reviews | Reviews are part of the field's epistemic discourse |
| Use non-exclusive family coding | Titles often combine problem, modality, population, process and outcome |
| Use period percentages | Counts alone would be biased by changing corpus size |
| Treat results as title-based discourse mapping | Avoid overclaiming full-text or keyword-level inference |

---

## 15. Current limitations

1. **Title-only corpus.**  
   The analysis maps title-level self-presentation, not full article content.

2. **No usable author-keyword layer.**  
   The keyword-pipeline failed because public landing pages did not expose keywords consistently.

3. **Partial abstract availability.**  
   Abstract coverage was too low to serve as the primary comparative layer.

4. **Rule-based family coding.**  
   Coding is transparent and auditable but cannot capture all semantic nuance.

5. **Non-exhaustive journal selection.**  
   The corpus is purposive, not a complete census of psychotherapy-related journals.

6. **Overlapping families.**  
   Multiple coding is methodologically appropriate but requires careful interpretation of percentages.

7. **Publisher and metadata effects.**  
   Record availability and article types may vary by publisher and journal.

---

## 16. Repository and workflow status

The workflow now has several major artifact layers:

```text
raw_full_v05
→ title input / QA layer
→ analysis candidate
→ analysis_v02
→ round1 exploratory analysis
→ phase2 family audit
→ round2 stable family analysis
→ round3 article outputs
```

Recommended repository structure:

```text
data_worldcorpus/
├── data_psychotherapy_journals/
│   ├── raw/
│   ├── raw_full_v05/
│   ├── qa/
│   └── qa_keyword_audit/
├── title_pipeline/
│   ├── input/
│   ├── qa/
│   ├── processed/
│   ├── family_audit/
│   ├── round2_family_analysis/
│   └── round3_article_outputs/
└── reports/
```

Recommended module structure:

```text
modules/
├── keywords_pipeline/
└── titles_pipeline/
```

---

## 17. Recommended next steps

### 17.1 Immediate

1. Commit Round 2 and Round 3 outputs to the repository.
2. Review all figures visually, especially heatmaps with long family labels.
3. Decide whether figure labels should be shortened for publication.
4. Prepare a final table/figure selection for the manuscript.

### 17.2 Analytical

1. Run sensitivity analysis excluding individual high-volume journals.
2. Run journal-specific profile interpretations.
3. Create a shorter set of “article families” for readable figures if necessary.
4. Inspect unassigned titles for missing families that may be substantively important.

### 17.3 Manuscript

1. Draft full Methods section.
2. Draft Results based on Round 3.
3. Draft Discussion around:
   - evolution of psychotherapy research discourse,
   - rise of synthesis, digital delivery and third-wave language,
   - outcome/process/professionalization axes,
   - title-based analysis as a reproducible compromise.
4. Decide target journal.

---

## 18. Proposed manuscript title options

1. **Mapping the Title-Level Discourse of Psychotherapy Research: A Bibliometric Analysis of Ten International Journals, 2005–2025**

2. **Two Decades of Psychotherapy Research in Titles: A Longitudinal Bibliometric Map of International Clinical and Psychotherapy Journals**

3. **From Outcomes to Digital Delivery: A Title-Based Discourse Map of Psychotherapy and Clinical Intervention Research, 2005–2025**

4. **The Changing Self-Presentation of Psychotherapy Research: A Title-Based Bibliometric Study of Ten International Journals**

---

## 19. Recommended acknowledgment

If this system is acknowledged in scholarly work:

> Bibliometric data preparation and semantic title-family normalization were supported by the research agent Andromeda Nowicka (v0.2), a human-in-the-loop computational bibliometrics system developed under the supervision of Lech Kalita.

Formal reference if needed:

> Andromeda Nowicka (v0.2). HITL bibliometric analysis agent for discourse mapping. Controller: Lech Kalita. DID: did:web:kalitalech-hash.github.io:andromeda.

---

## 20. Closing note

At this stage the project has moved from raw data acquisition into a stable, auditable analytical corpus with publication-oriented outputs. The most important methodological achievement is not merely the production of tables and figures, but the documented transformation of a failed keyword extraction attempt into a defensible title-based discourse mapping pipeline.

The current corpus is ready for manuscript development, sensitivity analyses and interpretive writing.
