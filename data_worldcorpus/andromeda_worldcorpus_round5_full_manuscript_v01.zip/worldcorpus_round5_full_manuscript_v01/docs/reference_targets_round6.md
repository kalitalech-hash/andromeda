# Reference targets for Round 6

This draft intentionally uses reference placeholders. Round 6 should ground the manuscript in the following literatures.

## Bibliometrics and science mapping
Needed for the general legitimacy of publication-level mapping, field mapping, and quantitative studies of scholarly communication.

## Title-based bibliometric analysis
Needed to justify article titles as a standardized, comparable layer of scholarly self-description.

## Author keywords and metadata limitations
Needed to support the methodological pivot away from author-keyword analysis when keyword metadata are unavailable or platform-dependent.

## Psychotherapy research and evidence-based practice
Needed to contextualize outcome/change/recovery, RCTs, evidence synthesis, CBT, and treatment-outcome discourse.

## Psychotherapy process and mechanisms
Needed to contextualize alliance/process, mediators/moderators, emotion regulation, self/identity/attachment, and therapist effects.

## Digital psychotherapy and telehealth
Needed to contextualize growth in digital/online/telehealth and the COVID-19 period.

## Third-wave and mindfulness/compassion approaches
Needed to contextualize growth in the third-wave/mindfulness/compassion family.

## Human-in-the-loop and AI-assisted research support
Needed to describe the role of Andromeda as a research support agent rather than an author.
