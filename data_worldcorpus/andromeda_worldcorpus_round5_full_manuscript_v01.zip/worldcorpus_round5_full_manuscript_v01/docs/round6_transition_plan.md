# Round 5 to Round 6 transition plan

## Round 5 status

This package contains a full manuscript draft v01. The argument, methods, results, tables, and discussion are present, but references are not yet finalized.

## Round 6 tasks

1. Add scholarly references and replace `[REF: ...]` placeholders.
2. Tailor length, heading style, and tables to the target journal.
3. Decide which figures remain in the main manuscript and which move to supplementary materials.
4. Shorten Methods if needed and move technical scraper details to supplementary materials.
5. Add final data/code availability statement with repository URL.
6. Finalize AI-assisted research-support declaration.
7. Prepare cover letter and submission checklist.
