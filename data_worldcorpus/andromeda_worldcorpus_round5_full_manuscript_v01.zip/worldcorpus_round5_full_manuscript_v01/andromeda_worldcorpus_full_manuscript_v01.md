# How Psychotherapy Research Describes Itself: A Title-Based Bibliometric Map of Ten International Journals, 2005–2025

**Short title:** Title-based bibliometric map of psychotherapy research

**Manuscript type:** Original article / bibliometric research article  
**Target journal:** *Scientometrics*  
**Status:** Round 5 full manuscript draft v01; literature grounding and final references still required.

## Abstract

This study maps two decades of international psychotherapy and clinical psychological intervention research using article titles as a standardized layer of scholarly self-description. A corpus of 14,229 titles published between 2005 and 2025 was assembled from ten journals representing psychotherapy research, clinical intervention research, cognitive-behavioral and behavioral clinical science, psychotherapy integration, counselling research, and creative arts therapies. The initial workflow attempted to extract author-assigned keywords from public article landing pages; however, a source audit showed that author keywords were not consistently exposed in public metadata. The project therefore shifted to a title-based bibliometric pipeline. After quality control and removal of non-substantive and supplemental-material records, titles were coded using an auditable, non-exclusive rule-based system of 26 thematic families. The most frequent family was outcome/change/recovery (18.67% of titles), followed by anxiety/fear/phobia/panic (11.93%), children/adolescents/youth (11.55%), training/supervision/therapist development (11.19%), depression and mood (10.82%), and CBT and cognitive-behavioral therapies (9.40%). The largest increases between 2005–2009 and 2020–2025 were observed for review/meta-analysis/synthesis (+6.10 percentage points), third-wave/mindfulness/compassion (+5.25), training/supervision/therapist development (+5.04), digital/online/telehealth (+4.79), and outcome/change/recovery (+4.69). The findings suggest that the title-level discourse of psychotherapy research is not organized solely around disorders and treatment modalities; it increasingly foregrounds evidence synthesis, outcomes, mechanisms, delivery systems, and professional development. The study demonstrates a human-in-the-loop title-based workflow for mapping field self-description when author-keyword metadata are unavailable or inconsistent.

**Keywords:** psychotherapy research; bibliometrics; title analysis; science mapping; clinical psychology; discourse mapping; human-in-the-loop

## 1. Introduction

Psychotherapy research is a heterogeneous field that cuts across clinical psychology, psychiatry, counselling, behavioral science, intervention research, and theory-driven traditions of therapeutic practice. Its journals publish randomized trials, process studies, reviews, psychometric papers, qualitative research, training studies, and clinically oriented theoretical work. This heterogeneity raises a basic metascientific question: how does the field publicly describe itself over time? Which problems, methods, populations, treatment models, process constructs, and epistemic formats are foregrounded in the most visible layer of scholarly communication?

Bibliometric and science-mapping approaches are well suited for addressing such questions because they allow large corpora of publications to be treated as structured traces of scholarly communication [REF: bibliometrics_general]. In psychotherapy research, however, metadata availability is not uniform. Author-assigned keywords are often attractive because they appear to condense the topical self-description of articles, but they are not consistently exposed across publishers, journal platforms, or historical periods. This creates a practical and methodological problem: a keyword-based map may appear precise while silently excluding large parts of the corpus.

The present study approaches this problem by treating article titles as a stable and comparable layer of field self-description. Titles are not substitutes for full text and do not exhaust article content. Yet they are highly standardized, widely available, and rhetorically consequential. A title must typically name what the article presents as its central problem, method, population, construct, intervention, or claim. At scale, titles therefore provide a useful lens on how a field chooses to make itself visible.

The study maps 14,229 titles from ten international journals between 2005 and 2025. The corpus was designed to capture a broad but coherent segment of psychotherapy and clinical psychological intervention research. It includes journals centrally devoted to psychotherapy research and practice, high-volume clinical intervention journals, cognitive-behavioral and behavioral clinical science journals, integration and counselling journals, and a journal representing creative arts therapies. The design was purposive rather than exhaustive: the aim was not to claim coverage of all psychotherapy-related literatures, but to construct a heterogeneous corpus that could reveal major shifts in title-level self-description across two decades.

The analysis asks four research questions. First, which thematic families dominate the title-level discourse of international psychotherapy and clinical intervention research? Second, which families increase or decline in relative visibility between 2005 and 2025? Third, how do journal profiles differ across thematic families? Fourth, what can a title-based human-in-the-loop workflow contribute when author-keyword metadata are unavailable or inconsistent?

## 2. Methods

### Corpus design and journal selection

The journal set was selected purposively rather than as a strict impact-factor ranking. The aim was to construct a broad yet coherent corpus covering major segments of international psychotherapy and clinical psychological intervention research. The sample included journals centrally devoted to psychotherapy research and practice, high-volume clinical intervention and clinical psychology journals, journals representing the cognitive-behavioral and behavioral clinical science tradition, journals focused on psychotherapy integration and counselling-practice links, and a journal representing creative arts therapies. This design was intended to capture heterogeneity within the psychotherapy research discourse rather than to exhaustively represent all psychotherapy-related journals.

The ten journals were: *Psychotherapy Research*, *Journal of Consulting and Clinical Psychology*, *Psychotherapy*, *Behaviour Research and Therapy*, *Cognitive Behaviour Therapy*, *Journal of Psychotherapy Integration*, *Clinical Psychology & Psychotherapy*, *Psychology and Psychotherapy: Theory, Research and Practice*, *Counselling and Psychotherapy Research*, and *The Arts in Psychotherapy*.

### Data acquisition and keyword-source audit

The initial workflow attempted to build an author-keyword corpus. Records were gathered through DOI-level bibliographic metadata and publisher landing pages. A sequence of scraper versions was developed to handle Crossref querying, pagination, timeouts, retry logic, logging, and per-journal output. The full scrape produced a bibliographic corpus of article records across the target years. However, public landing pages did not expose author-assigned keywords in a consistent or recoverable form. A targeted keyword-source audit across sampled landing pages searched for common metadata signals such as citation keywords, Dublin Core subject fields, JSON-LD keyword fields, and visible keyword sections. No stable keyword signal was detected across the corpus.

This negative result led to a methodological pivot. Rather than treating missing keywords as random absence, the project transferred the corpus to a title-based pipeline. This decision is important because it avoids constructing a biased keyword corpus from only those publishers or platforms that expose keyword metadata.

### Cleaning and analytical corpus

The title corpus was created from the raw bibliographic layer through a quality-control workflow. Records were deduplicated by article identifiers and DOI. Non-substantive records such as book reviews, notices, guide-for-authors records, corrections, editorial-board matter, and similar technical records were flagged. Review articles were retained because they were interpreted as part of the epistemic discourse of the field. Supplemental and supplementary material records were excluded because they represent technical metadata rather than substantive article titles and showed a strong risk of appearing as a false rising topic.

The final analytical corpus contained 14,229 titles from 10 journals published between 2005 and 2025. The corpus was divided into four periods: 2005–2009, 2010–2014, 2015–2019, and 2020–2025. The last period contains six years because the project scope extended through 2025.

### Title-family coding

A rule-based thematic family system was developed through a human-in-the-loop procedure. The first exploratory analysis identified frequent terms and provisional thematic families. A family-audit pack was then generated, including random matched samples, high-overlap samples, short-title samples, unassigned-title samples, and multi-family conflict cases. After review, the rulebook was accepted as the version used for the stable analysis.

The final rulebook contained 26 non-exclusive thematic families. Families were grouped into types such as clinical problem, therapeutic modality, process/mechanism, population context, delivery system, method/measurement, professional context, outcome evaluation, method-epistemic, historical context, and clinical context. Coding was non-exclusive because titles frequently combine several dimensions, for example a clinical problem, treatment modality, population, outcome, and mechanism.

### Analysis

For each thematic family, title-level document frequency was calculated. Period-specific percentages were calculated relative to the total number of titles in each period. Journal profiles were calculated as within-journal percentages. Longitudinal change was summarized as percentage-point change between 2005–2009 and 2020–2025. Families were classified descriptively as persistent rising, persistent stable, persistent falling, emerging, or intermittent based on presence across periods and direction of percentage-point change. Family co-occurrence was defined as the co-presence of two families in the same title.

All transformations were preserved as layered outputs: raw bibliographic files, quality-control files, cleaned title corpus, family assignments, trend tables, journal profiles, co-occurrence edges, figure files, and manuscript-ready tables. The workflow was supported by Andromeda Nowicka, a human-in-the-loop research support agent used for bibliometric data preparation, QA, semantic auditing, and drafting support. Analytical decisions remained under human supervision.

## 3. Results

### Corpus composition

The final corpus contained 14,229 titles from ten journals between 2005 and 2025. The largest journal contribution came from *Behaviour Research and Therapy* (2,953 titles), followed by *Journal of Consulting and Clinical Psychology* (1,996), *Clinical Psychology & Psychotherapy* (1,732), and *Psychotherapy Research* (1,506). The percentage of titles assigned at least one thematic family ranged from 66.77% in *Journal of Psychotherapy Integration* to 91.09% in *Cognitive Behaviour Therapy*. Across the full corpus, 11,624 titles (81.69%) received at least one family assignment.

### Dominant thematic families

The most frequent thematic family was outcome/change/recovery, assigned to 2,657 titles (18.67%). This was followed by anxiety/fear/phobia/panic (1,697 titles; 11.93%), children/adolescents/youth (1,644; 11.55%), training/supervision/therapist development (1,592; 11.19%), depression and mood (1,539; 10.82%), and CBT and cognitive-behavioral therapies (1,337; 9.40%). Other prominent families included self/identity/attachment, trauma/PTSD/stress, emotion/regulation/affect, mechanisms/mediators/moderators, alliance/process/relationship, and assessment/measurement/psychometrics.

This distribution indicates that the corpus is not organized only around diagnostic categories or named treatment modalities. Its title-level discourse also foregrounds outcome evaluation, change, professional development, therapeutic process, mechanisms, measurement, and populations.

### Longitudinal shifts

The strongest increase between 2005–2009 and 2020–2025 was observed for review/meta-analysis/synthesis, rising from 1.535% to 7.639% of titles (+6.104 percentage points). Third-wave/mindfulness/compassion increased from 1.637% to 6.883% (+5.246). Training/supervision/therapist development increased from 7.708% to 12.751% (+5.043), and digital/online/telehealth increased from 1.739% to 6.525% (+4.786). Outcome/change/recovery also increased from 14.666% to 19.355% (+4.689). COVID-19/pandemic was the only explicitly emerging family, absent in the first period and appearing in the final period.

These shifts suggest both substantive and epistemic change. The field increasingly marks evidence synthesis, newer therapeutic approaches, digital delivery systems, professional development, outcome evaluation, and mechanism-oriented constructs in its titles.

Relative declines should be interpreted cautiously. Anxiety/fear/phobia/panic was classified as persistent falling because its share declined from 12.585% to 11.140%, even though its absolute count was highest in the final period. This pattern illustrates why percentage shares are more informative than raw counts in a growing corpus. Decline in share does not imply disappearance; it often indicates diversification of the title discourse.

### Journal profiles

Journal profiles showed substantial heterogeneity. *Behaviour Research and Therapy* was characterized by high visibility of anxiety/fear/phobia/panic, CBT and cognitive-behavioral therapies, emotion/regulation/affect, and eating/body image. *Journal of Consulting and Clinical Psychology* foregrounded outcome/change/recovery, children/adolescents/youth, depression and mood, CBT, mechanisms, and substance use/addiction. *Clinical Psychology & Psychotherapy* showed distinctive visibility of assessment/measurement/psychometrics, review/synthesis, personality/BPD, and psychosis/schizophrenia. *The Arts in Psychotherapy* was, as expected, distinctive for arts/creative therapies, while *Journal of Psychotherapy Integration* was more strongly characterized by integration-relevant process and professional themes.

These profiles support the decision to treat the corpus as a heterogeneous field map rather than as a single homogeneous psychotherapy literature. The ten-journal design captures different discursive centers: trial-oriented clinical intervention research, behavioral clinical science, psychotherapy process research, counselling/practice discourse, integration, and creative arts therapies.

### Co-occurrence structure

Co-occurrence analysis showed that outcome/change/recovery was a central connector. Its strongest co-occurrences included mechanisms/mediators/moderators (471 co-occurring titles), CBT and cognitive-behavioral therapies (426), depression and mood (376), anxiety/fear/phobia/panic (332), children/adolescents/youth (310), training/supervision/therapist development (308), and alliance/process/relationship (300). Other strong links included CBT with anxiety (339), CBT with depression (306), anxiety with depression (303), and children/adolescents/youth with couple/family/relationship (329).

The co-occurrence structure reinforces the interpretation that title-level psychotherapy discourse often combines clinical problem domains with outcome evaluation, therapeutic modality, developmental or relational context, process mechanisms, and professional practice.

### Table 1. Corpus composition by journal

| Journal                                                     |   Titles |   First year |   Last year |   Titles with family (%) |   Mean families/title |
|:------------------------------------------------------------|---------:|-------------:|------------:|-------------------------:|----------------------:|
| Behaviour Research and Therapy                              |     2953 |         2005 |        2025 |                    82.73 |                  1.71 |
| Journal of Consulting and Clinical Psychology               |     1996 |         2005 |        2025 |                    89.68 |                  2.02 |
| Clinical Psychology & Psychotherapy                         |     1732 |         2005 |        2025 |                    86.26 |                  1.8  |
| Psychotherapy Research                                      |     1506 |         2005 |        2025 |                    84.06 |                  1.79 |
| Counselling and Psychotherapy Research                      |     1372 |         2005 |        2025 |                    68.44 |                  1.16 |
| The Arts in Psychotherapy                                   |     1281 |         2005 |        2025 |                    80.8  |                  1.5  |
| Psychotherapy                                               |     1109 |         2005 |        2025 |                    76.47 |                  1.48 |
| Psychology and Psychotherapy: Theory, Research and Practice |      899 |         2005 |        2025 |                    78.31 |                  1.62 |
| Cognitive Behaviour Therapy                                 |      752 |         2005 |        2025 |                    91.09 |                  1.98 |
| Journal of Psychotherapy Integration                        |      629 |         2005 |        2025 |                    66.77 |                  1.21 |

### Table 2. Top thematic families overall

| Family                                         | Family type          |   Titles |   % of titles |
|:-----------------------------------------------|:---------------------|---------:|--------------:|
| outcome / change / recovery                    | outcome_evaluation   |     2657 |         18.67 |
| anxiety / fear / phobia / panic                | clinical_problem     |     1697 |         11.93 |
| children / adolescents / youth                 | population_context   |     1644 |         11.55 |
| training / supervision / therapist development | professional_context |     1592 |         11.19 |
| depression and mood                            | clinical_problem     |     1539 |         10.82 |
| CBT and cognitive-behavioral therapies         | therapeutic_modality |     1337 |          9.4  |
| self / identity / attachment                   | process_mechanism    |     1255 |          8.82 |
| trauma / PTSD / stress                         | clinical_problem     |     1136 |          7.98 |
| emotion / regulation / affect                  | process_mechanism    |     1069 |          7.51 |
| mechanisms / mediators / moderators            | process_mechanism    |      989 |          6.95 |
| alliance / process / relationship              | process_mechanism    |      955 |          6.71 |
| assessment / measurement / psychometrics       | method_measurement   |      806 |          5.66 |
| third-wave / mindfulness / compassion          | therapeutic_modality |      715 |          5.02 |
| arts / creative therapies                      | therapeutic_modality |      703 |          4.94 |
| digital / online / telehealth                  | delivery_system      |      635 |          4.46 |

### Table 3. Fastest-rising families

| family                                         | family_type          |   total |   2005-2009_pct |   2020-2025_pct |   delta_pct_last_first | status            |
|:-----------------------------------------------|:---------------------|--------:|----------------:|----------------:|-----------------------:|:------------------|
| review / meta-analysis / synthesis             | method_epistemic     |     634 |           1.535 |           7.639 |                  6.104 | persistent_rising |
| third-wave / mindfulness / compassion          | therapeutic_modality |     715 |           1.637 |           6.883 |                  5.246 | persistent_rising |
| training / supervision / therapist development | professional_context |    1592 |           7.708 |          12.751 |                  5.043 | persistent_rising |
| digital / online / telehealth                  | delivery_system      |     635 |           1.739 |           6.525 |                  4.786 | persistent_rising |
| outcome / change / recovery                    | outcome_evaluation   |    2657 |          14.666 |          19.355 |                  4.689 | persistent_rising |
| COVID-19 / pandemic                            | historical_context   |     158 |           0     |           3.143 |                  3.143 | emerging          |
| emotion / regulation / affect                  | process_mechanism    |    1069 |           6.241 |           9.031 |                  2.79  | persistent_rising |
| mechanisms / mediators / moderators            | process_mechanism    |     989 |           5.014 |           7.679 |                  2.665 | persistent_rising |
| arts / creative therapies                      | therapeutic_modality |     703 |           3.274 |           5.669 |                  2.395 | persistent_rising |
| alliance / process / relationship              | process_mechanism    |     955 |           5.218 |           6.943 |                  1.725 | persistent_rising |
| implementation / services / access             | delivery_system      |     606 |           3.854 |           5.132 |                  1.278 | persistent_rising |
| depression and mood                            | clinical_problem     |    1539 |           9.754 |          11.02  |                  1.266 | persistent_rising |

### Table 4. Fastest-falling or relatively declining families

| family                          | family_type          |   total |   2005-2009_pct |   2020-2025_pct |   delta_pct_last_first | status             |
|:--------------------------------|:---------------------|--------:|----------------:|----------------:|-----------------------:|:-------------------|
| anxiety / fear / phobia / panic | clinical_problem     |    1697 |          12.585 |          11.14  |                 -1.445 | persistent_falling |
| eating / body image             | clinical_problem     |     559 |           3.581 |           2.904 |                 -0.677 | persistent_stable  |
| couple / family / relationship  | population_context   |     507 |           3.854 |           3.402 |                 -0.452 | persistent_stable  |
| psychodynamic / psychoanalytic  | therapeutic_modality |     360 |           2.49  |           2.109 |                 -0.381 | persistent_stable  |
| somatic / medical comorbidity   | clinical_context     |     467 |           3.547 |           3.223 |                 -0.324 | persistent_stable  |
| personality / BPD               | clinical_problem     |     508 |           3.718 |           3.402 |                 -0.316 | persistent_stable  |
| culture / diversity / identity  | population_context   |     474 |           3.82  |           3.601 |                 -0.219 | persistent_stable  |
| substance use / addiction       | clinical_problem     |     450 |           2.353 |           2.506 |                  0.153 | persistent_stable  |
| children / adolescents / youth  | population_context   |    1644 |          11.562 |          11.796 |                  0.234 | persistent_stable  |
| psychosis / schizophrenia       | clinical_problem     |     319 |           1.842 |           2.288 |                  0.446 | persistent_stable  |

## 4. Discussion

The findings suggest that international psychotherapy and clinical intervention research increasingly describes itself through a combination of outcome evaluation, evidence synthesis, process mechanisms, digital delivery, therapist development, and diversified therapeutic approaches. Disorder categories remain highly visible, especially anxiety, depression, trauma, eating/body image, personality, substance use, and psychosis. Yet these categories are embedded in a broader discourse that emphasizes change, mechanisms, measurement, implementation, professional competence, and evidence synthesis.

One of the clearest patterns is the prominence and growth of outcome/change/recovery. This is not surprising in a field strongly shaped by evidence-based practice, clinical trials, and outcome research. However, the family’s dominance across journals and periods indicates that outcome language is not confined to trial-oriented journals. It functions as a general organizing vocabulary of the field.

A second major pattern is the growth of review/meta-analysis/synthesis. This suggests maturation and consolidation of the literature. As research areas expand, titles increasingly foreground systematic reviews, meta-analyses, and other synthesis formats. This trend may indicate both accumulation of evidence and a shift in what counts as a visible scholarly contribution.

Third, the rise of third-wave/mindfulness/compassion and digital/online/telehealth points to changing modalities and delivery systems. These developments likely reflect broader transformations in clinical practice, technology, and intervention research. The digital/online/telehealth family predates the COVID-19 period but becomes more visible in the final period, suggesting that the pandemic amplified rather than created this axis of title-level discourse.

Fourth, the growth of training/supervision/therapist development highlights the professionalization of psychotherapy research. The field increasingly marks therapist competence, training, adherence, fidelity, and supervision in titles. This suggests that research attention is not limited to interventions and patient outcomes but also extends to the conditions under which treatments are delivered.

Fifth, process and mechanism families such as alliance/process/relationship, mechanisms/mediators/moderators, emotion/regulation/affect, and self/identity/attachment demonstrate that the field is not merely asking whether interventions work. It also increasingly asks how change occurs, under what conditions, and through which relational, emotional, cognitive, or professional pathways.

The study also has a methodological implication. The failed keyword extraction was not merely a technical inconvenience. It revealed a metadata limitation that matters for bibliometric research. Author-keyword analysis can be attractive, but if keyword availability depends on publisher platform practices, a keyword corpus may become systematically biased. The title-based pivot offered a more stable and inclusive alternative. Titles are a thinner source than abstracts or full text, but they are also more consistently available and comparable across journals and years.

The study contributes to science mapping by demonstrating a human-in-the-loop title-based workflow that is reproducible, auditable, and suitable for fields with inconsistent keyword metadata. It also contributes substantively by showing how psychotherapy research publicly describes itself over two decades: as a field increasingly organized by outcomes, synthesis, mechanisms, delivery systems, professional development, and diversified therapeutic traditions.

## 5. Limitations

Several limitations should be noted. First, the analysis is based on article titles. Titles are indicators of public self-presentation, not full representations of article content. A construct may be central to an article without appearing in its title, and title wording may be shaped by editorial conventions, rhetorical strategies, or indexing practices.

Second, the journal set is purposive rather than exhaustive. Important adjacent literatures, including psychoanalysis, family therapy, group psychotherapy, implementation science, counselling psychology, and body-oriented or humanistic traditions, may require dedicated supplementary corpora. The present corpus should therefore be interpreted as a broad comparative map of selected international psychotherapy and clinical intervention journals, not as a complete map of all psychotherapy research.

Third, the family coding is rule-based. This makes the workflow transparent and auditable, but it also means that false positives and false negatives are possible. Non-exclusive coding was used because titles often combine multiple conceptual dimensions. The resulting families are best understood as aggregate thematic probes rather than definitive semantic classifications.

Fourth, the final period covers six years (2020–2025), while earlier periods cover five years. Percentages within periods were used to reduce the effect of unequal period length, but the final period remains shaped by COVID-19, rapid growth in digital delivery, and recent publication practices.

Fifth, the analysis did not use abstracts or full texts as primary data. Abstracts were only partially available in the bibliographic metadata and were therefore not used as the main analytical layer. Future work could compare title-based, abstract-based, keyword-based, and full-text maps where licensing and data access permit.

## 6. Conclusion

This study mapped the title-level self-description of psychotherapy and clinical intervention research across ten international journals from 2005 to 2025. The results show a field whose public scholarly vocabulary is organized not only by disorders and treatment modalities, but also by outcome evaluation, evidence synthesis, mechanisms of change, digital delivery, therapist development, and process-oriented constructs. The title-based approach also demonstrates a practical response to inconsistent author-keyword metadata: rather than constructing a partial and potentially biased keyword corpus, titles can serve as a stable and auditable layer for bibliometric discourse mapping. The study provides both a substantive map of changing psychotherapy research discourse and a reproducible human-in-the-loop workflow for future science-mapping projects.

## Data and code availability

All analysis outputs were organized as layered research artifacts: raw bibliographic data, QA outputs, title-pipeline input files, family assignments, trend tables, journal profiles, co-occurrence edges, figures, and manuscript-ready tables. Repository paths and final public data/code availability statements should be finalized before submission. Any non-public or copyrighted material should be excluded from the public repository.

## Acknowledgments and AI-assisted research support

Bibliometric data preparation, quality-control structuring, semantic family auditing, table generation, and drafting support were assisted by the research agent Andromeda Nowicka (v0.2), a human-in-the-loop computational bibliometrics system developed under the supervision of Lech Kalita. The system was used as a research support tool, not as an independent author. All methodological decisions, interpretation, and responsibility for the manuscript remain with the human researcher.

## Supplementary materials plan

Supplementary materials should include the full journal-level tables, family rulebook, family assignment tables, co-occurrence edges, QA decision logs, and details of the keyword-source audit and title-pipeline workflow.

## References

References to be completed in Round 6. Target areas:
- general bibliometrics and science mapping;
- title-based bibliometric or discourse mapping;
- psychotherapy research trends and evidence-based practice;
- metadata limitations and author-keyword availability;
- human-in-the-loop AI or research-agent support in scholarly workflows;
- journal-scope references if required for corpus justification.
