# Supplementary materials plan — Round 5

## Supplement A. Data acquisition and QA
- Scraper development notes and final Crossref/landing-page workflow.
- Keyword-source audit report documenting the absence of stable public author-keyword metadata.
- QA tables for raw bibliographic records and title-corpus construction.

## Supplement B. Family rulebook and coding
- Full family rulebook v02.
- Regex patterns and operational definitions.
- Family assignment matrix and long-format family assignments.
- Unassigned-title and multi-family overlap audit summaries.

## Supplement C. Extended results
- Full family × period table.
- Full journal × family table.
- Distinctive families by journal.
- Full family co-occurrence edge list.
- Figures in high-resolution PNG.

## Supplement D. Reproducibility package
- Analysis scripts.
- README with execution order.
- Versioned outputs and transformation logs.
