# Round 4 decision memo

## Strategic decision

The world corpus manuscript is framed for *Scientometrics* as an original research article in science mapping / bibliometrics, while retaining a clinically meaningful question: how psychotherapy research publicly describes itself in article titles.

## Why Scientometrics first?

*Scientometrics* publishes original research on quantitative aspects of the production, communication, and use of scientific and technological information. This makes it a suitable venue for a title-based bibliometric map of psychotherapy research discourse.

## Core contribution

1. Empirical: a 2005–2025 title-based map of ten international psychotherapy/clinical intervention journals.
2. Methodological: a human-in-the-loop workflow for title-based field mapping when author keyword metadata are unavailable.
3. Interpretive: evidence of a shift toward outcome evaluation, synthesis, professionalization, digital delivery, mechanisms, and process-oriented self-description.

## Working title

How Psychotherapy Research Describes Itself: A Title-Based Bibliometric Map of Ten International Journals, 2005–2025

## Next work package

Round 5 should convert this skeleton into a full manuscript:

1. Expand Introduction with literature.
2. Convert Methods into article-ready prose.
3. Insert Tables 1–5 and Figures 1–6.
4. Refine Results using Round 3 outputs.
5. Write Discussion around 4–5 interpretive claims.
6. Prepare Supplementary Materials and data/code availability statement.
