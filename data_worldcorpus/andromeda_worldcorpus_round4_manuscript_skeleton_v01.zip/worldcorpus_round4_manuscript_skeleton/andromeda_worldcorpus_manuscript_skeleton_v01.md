# How Psychotherapy Research Describes Itself: A Title-Based Bibliometric Map of Ten International Journals, 2005–2025

**Short title:** Title-Based Bibliometric Map of Psychotherapy Research

**Target journal:** *Scientometrics*  
**Manuscript type:** Original research article  
**Working version:** Round 4 manuscript skeleton v01  
**Date:** 2026-05-19

## Abstract

This study maps two decades of international psychotherapy and clinical psychological intervention research through article titles. The initial project attempted to construct an author-keyword corpus from Crossref-indexed article landing pages, but a source audit showed that author-assigned keywords were not consistently exposed in public metadata. The study therefore developed a human-in-the-loop title-based bibliometric workflow for mapping field self-description when keyword metadata are unavailable or inconsistent. The corpus comprised 14,229 article titles from ten international journals published between 2005 and 2025. Titles were cleaned, periodized, and coded into 26 auditable thematic families covering clinical problems, therapeutic modalities, process and mechanism constructs, professional contexts, populations, delivery systems, epistemic formats, and outcome evaluation. Results show that the title-level discourse is organized not only around clinical problems such as anxiety, depression, trauma, and youth/family contexts, but also around outcome/change/recovery, therapist training and supervision, CBT, alliance and process, mechanisms, measurement, digital delivery, and evidence synthesis. The strongest increases were observed for review/meta-analysis/synthesis, third-wave/mindfulness/compassion approaches, training and supervision, digital/online/telehealth delivery, outcome/change/recovery, COVID-19/pandemic, emotion regulation, mechanisms/mediators/moderators, creative arts therapies, and alliance/process. The findings suggest a field increasingly shaped by evaluation, synthesis, professionalization, delivery systems, and mechanism-oriented self-description. The article contributes both a reproducible workflow for title-based science mapping and an empirical account of how psychotherapy research publicly describes itself over time.

**Keywords:** bibliometrics, scientometrics, psychotherapy research, title analysis, science mapping, clinical psychology, research discourse, human-in-the-loop

---

# 1. Introduction

## 1.1. Psychotherapy research as a heterogeneous scientific field

Psychotherapy research is a heterogeneous domain spanning clinical trials, process and outcome research, therapist training and supervision, counselling research, cognitive-behavioural and behavioural clinical science, integrative psychotherapy, and creative arts therapies. This heterogeneity makes the field difficult to characterize through a single theoretical, clinical, or methodological lens. Bibliometric and scientometric approaches can help describe how such fields organize and present their research priorities over time.

## 1.2. From author keywords to title-based field self-description

The project was originally designed as an author-keyword analysis. However, a keyword-source audit of public article landing pages showed that author-assigned keywords were not consistently exposed in retrievable public metadata. Rather than treating this as a purely technical failure, the study redefined its analytical layer: article titles were used as standardized indicators of field self-description.

Titles are not full texts. They do not represent the complete conceptual content of an article. However, they are highly visible, standardized, consistently available, and editorially constrained. They represent the public-facing formulation of a publication’s central problem, method, population, intervention, or claim.

## 1.3. Aim of the study

This study asks:

1. What thematic families dominate the title-level self-description of international psychotherapy and clinical intervention research between 2005 and 2025?
2. Which thematic families increased, decreased, emerged, or persisted across the four analytical periods?
3. How do journal profiles differ in their title-level thematic composition?
4. What does title-based mapping reveal about broader shifts in the field’s epistemic and clinical priorities?

# 2. Methods

## 2.1. Corpus design and journal selection

The corpus was constructed from ten international journals selected purposively rather than as an impact-factor ranking. The aim was to capture a broad yet coherent field of psychotherapy research, clinical psychological intervention research, cognitive-behavioural and behavioural clinical science, psychotherapy integration, counselling research, and creative arts therapies.

The journal set included:

- *Psychotherapy Research*
- *Journal of Consulting and Clinical Psychology*
- *Psychotherapy*
- *Behaviour Research and Therapy*
- *Cognitive Behaviour Therapy*
- *Journal of Psychotherapy Integration*
- *Clinical Psychology & Psychotherapy*
- *Psychology and Psychotherapy: Theory, Research and Practice*
- *Counselling and Psychotherapy Research*
- *The Arts in Psychotherapy*

The selection was intended to represent major segments of international psychotherapy-related research rather than to exhaust all adjacent fields. Important neighbouring domains, including psychoanalysis, family therapy, group psychotherapy, body psychotherapy, counselling psychology, and implementation science, may require dedicated supplementary corpora.

## 2.2. Data acquisition

Article metadata were acquired through a Crossref-based workflow that queried DOI-level records by journal and publication year. For each record, article-level metadata and article landing pages were processed. The original pipeline attempted to retrieve author-assigned keywords from public landing-page metadata, JSON-LD, citation metadata, and visible HTML sections.

## 2.3. Keyword-source audit and methodological pivot

A keyword-source audit was performed on sampled article landing pages from all journals. The audit did not detect consistent public HTML or metadata signals for author-assigned keywords. Consequently, the author-keyword pipeline was not used as the primary analytical layer. The corpus was transferred to a title-based pipeline.

This pivot is methodologically important: the analysis does not claim to map author keywords or full-text content. It maps title-level article self-presentation.

## 2.4. Cleaning and exclusion rules

The initial title corpus was cleaned by excluding non-substantive records and technical metadata records. Supplemental and supplementary material records were removed. Review articles were retained as part of the field’s epistemic discourse.

The final analytical corpus included **14,229 titles** from **10 journals** published between **2005 and 2025**.

## 2.5. Periodization

The corpus was divided into four analytical periods:

- 2005–2009
- 2010–2014
- 2015–2019
- 2020–2025

The final period contains six years because the project scope extended through 2025.

## 2.6. Thematic family coding

A human-in-the-loop rule-based thematic family system was developed and audited. The final accepted rulebook contained **26 thematic families**. Families covered clinical-problem, therapeutic-modality, process/mechanism, population/context, method/measurement, delivery-system, professional-context, outcome-evaluation, historical-context, and method-epistemic categories.

Coding was non-exclusive: a title could be assigned to more than one family. This was intentional because article titles often combine multiple dimensions, such as a clinical problem, therapeutic modality, population, outcome, and process or delivery marker.

## 2.7. Analysis

Document frequencies were calculated at the title level. Period-specific percentages were calculated relative to the total number of titles in each period. Journal profiles were calculated as within-journal percentages. Longitudinal change was summarized as percentage-point change between 2005–2009 and 2020–2025. Family co-occurrence was defined as the co-presence of two thematic families in the same title.

# 3. Results

## 3.1. Corpus composition

**Table 1.** Corpus composition by journal.  
[Insert Table 1 here.]

**Figure 1.** Corpus size by journal.  
[Insert Figure 1 here.]

**Figure 2.** Corpus size by analytical period.  
[Insert Figure 2 here.]

## 3.2. Dominant thematic families

The most frequent family was **outcome / change / recovery**, assigned to 18.67% of titles. Other dominant families included anxiety/fear/phobia/panic, children/adolescents/youth, training/supervision/therapist development, depression and mood, CBT and cognitive-behavioral therapies, self/identity/attachment, trauma/PTSD/stress, emotion/regulation/affect, mechanisms/mediators/moderators, alliance/process/relationship, and assessment/measurement/psychometrics.

**Table 3. Top thematic families overall.**

| Family                                         | Family type          |   Titles |   % of titles |
|:-----------------------------------------------|:---------------------|---------:|--------------:|
| outcome / change / recovery                    | outcome_evaluation   |     2657 |         18.67 |
| anxiety / fear / phobia / panic                | clinical_problem     |     1697 |         11.93 |
| children / adolescents / youth                 | population_context   |     1644 |         11.55 |
| training / supervision / therapist development | professional_context |     1592 |         11.19 |
| depression and mood                            | clinical_problem     |     1539 |         10.82 |
| CBT and cognitive-behavioral therapies         | therapeutic_modality |     1337 |          9.4  |
| self / identity / attachment                   | process_mechanism    |     1255 |          8.82 |
| trauma / PTSD / stress                         | clinical_problem     |     1136 |          7.98 |
| emotion / regulation / affect                  | process_mechanism    |     1069 |          7.51 |
| mechanisms / mediators / moderators            | process_mechanism    |      989 |          6.95 |
| alliance / process / relationship              | process_mechanism    |      955 |          6.71 |
| assessment / measurement / psychometrics       | method_measurement   |      806 |          5.66 |

## 3.3. Longitudinal shifts

The strongest increases between 2005–2009 and 2020–2025 were observed for evidence synthesis/review discourse, third-wave/mindfulness/compassion approaches, therapist training and supervision, digital/online/telehealth delivery, outcome/change/recovery, COVID-19/pandemic, emotion regulation, mechanisms/mediators/moderators, creative arts therapies, and alliance/process.

**Table 4. Rising thematic families.**

| Family                                         | Family type          |   Total family-coded titles |   2005–2009 % |   2020–2025 % |   Δ pp 2020–2025 vs 2005–2009 |
|:-----------------------------------------------|:---------------------|----------------------------:|--------------:|--------------:|------------------------------:|
| review / meta-analysis / synthesis             | method_epistemic     |                         634 |         1.535 |         7.639 |                         6.104 |
| third-wave / mindfulness / compassion          | therapeutic_modality |                         715 |         1.637 |         6.883 |                         5.246 |
| training / supervision / therapist development | professional_context |                        1592 |         7.708 |        12.751 |                         5.043 |
| digital / online / telehealth                  | delivery_system      |                         635 |         1.739 |         6.525 |                         4.786 |
| outcome / change / recovery                    | outcome_evaluation   |                        2657 |        14.666 |        19.355 |                         4.689 |
| COVID-19 / pandemic                            | historical_context   |                         158 |         0     |         3.143 |                         3.143 |
| emotion / regulation / affect                  | process_mechanism    |                        1069 |         6.241 |         9.031 |                         2.79  |
| mechanisms / mediators / moderators            | process_mechanism    |                         989 |         5.014 |         7.679 |                         2.665 |
| arts / creative therapies                      | therapeutic_modality |                         703 |         3.274 |         5.669 |                         2.395 |
| alliance / process / relationship              | process_mechanism    |                         955 |         5.218 |         6.943 |                         1.725 |

**Figure 3.** Top thematic families by period.  
[Insert Figure 3 here.]

**Figure 5.** Fastest-rising thematic families.  
[Insert Figure 5 here.]

## 3.4. Journal profiles

Journal-level profiles showed substantial heterogeneity, supporting the interpretation of the corpus as a heterogeneous field map rather than a homogeneous literature. The profile tables identify both the most frequent families within each journal and families distinctive relative to their corpus-wide prevalence.

**Table 5.** Journal profiles.  
[Insert Table 5 here.]

**Figure 4.** Journal profiles by top thematic families.  
[Insert Figure 4 here.]

## 3.5. Family co-occurrence structure

Family co-occurrence analysis identified which thematic dimensions are jointly foregrounded in article titles. The strongest co-occurrences connected outcome/change with clinical-problem categories, process/mechanism categories, professional development, and therapeutic modalities.

**Figure 6.** Strongest thematic family co-occurrences.  
[Insert Figure 6 here.]

# 4. Discussion

## 4.1. Main findings

The title corpus suggests that international psychotherapy and clinical psychological intervention research is not organized solely around diagnostic categories. While anxiety, depression, trauma, youth, and CBT remain highly visible, the field’s title-level self-description is strongly shaped by outcome evaluation, mechanisms, evidence synthesis, professional development, digital delivery, emotion regulation, and therapeutic process.

## 4.2. A shift toward evaluation, synthesis, and mechanisms

The growth of review/meta-analysis/synthesis, outcome/change/recovery, and mechanisms/mediators/moderators suggests increasing emphasis on evaluation, aggregation of evidence, and explanatory process models. This pattern is consistent with a broader movement toward evidence synthesis and mechanism-oriented clinical science.

## 4.3. Professionalization and delivery systems

The increase in training/supervision/therapist development and digital/online/telehealth indicates that psychotherapy research is increasingly concerned with how interventions are delivered, by whom, and under what professional or technological conditions.

## 4.4. Clinical continuity and thematic diversification

Classical clinical topics did not disappear. Anxiety, depression, trauma, youth/family contexts, and CBT remain major axes. However, their relative position is embedded in a broader, more diversified discourse of outcomes, mechanisms, implementation, delivery systems, and epistemic synthesis.

## 4.5. Contribution to scientometrics

The study contributes a transparent, auditable title-based workflow for field mapping when author-keyword metadata are absent, inconsistent, or inaccessible. It also demonstrates how a domain-specific human-in-the-loop semantic layer can be used to translate short bibliographic records into interpretable thematic families.

# 5. Limitations

First, the analysis is based on titles, not full texts. Titles map public-facing self-description, not complete article content.

Second, the journal set was purposive and does not exhaust all psychotherapy-related literatures. Psychoanalysis, family therapy, group psychotherapy, body psychotherapy, and other adjacent areas may require separate corpora.

Third, rule-based thematic family coding is reproducible and auditable but cannot capture every semantic nuance.

Fourth, author keywords were unavailable in public landing-page metadata, which motivated the title-based approach but prevents direct comparison between title-based and keyword-based self-description within this corpus.

# 6. Conclusion

This title-based bibliometric map shows that from 2005 to 2025, psychotherapy and clinical psychological intervention research increasingly described itself through outcomes, synthesis, mechanisms, digital delivery, professional development, and process-oriented constructs, while retaining strong clinical-problem and modality-based axes. The study offers both an empirical map of field self-description and a reproducible workflow for title-based scientometric analysis when keyword metadata are unavailable.

# Data and code availability

Data transformation scripts, rulebooks, and derived analytical tables are intended to be deposited in the project repository. Raw data availability is subject to the metadata sources and publisher landing-page access conditions.

# Acknowledgments

Bibliometric data preparation and semantic title-family normalization were supported by the research agent Andromeda Nowicka (v0.2), a human-in-the-loop computational bibliometrics system developed under the supervision of Lech Kalita.

# Declaration on AI-assisted research support

Andromeda Nowicka was used as a research support agent for pipeline design, data cleaning, semantic audit support, table generation, and draft preparation. Final methodological decisions, interpretation, and responsibility for the manuscript remain with the human researcher.

# Supplementary materials

- Supplementary File 1: Full family rulebook.
- Supplementary File 2: Corpus composition and QA logs.
- Supplementary File 3: Family-by-period trends.
- Supplementary File 4: Journal profiles.
- Supplementary File 5: Co-occurrence edges and network nodes.
