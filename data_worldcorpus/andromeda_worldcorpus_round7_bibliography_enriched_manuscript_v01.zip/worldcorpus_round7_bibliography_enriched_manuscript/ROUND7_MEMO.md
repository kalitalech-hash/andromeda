# Round 7 memo — bibliography enrichment

## Decision

Round 7 preserves the Round 6 manuscript text and enriches the reference list only.

## Reference count

- References in Round 7: 30
- Main additions: bibliometric methodology, science mapping, reporting transparency, growth of science, title/term/co-word mapping, psychotherapy evidence/context, CBT, third-wave/process-based therapy, digital interventions, and psychotherapy relationship/process literature.

## Scope of changes

No analytical results, tables, figures, methods descriptions, or conclusions were substantively changed in this round. The purpose was to make the manuscript more submission-ready for a scientometrics/science-mapping audience while preserving the existing argument.

## Files

- `andromeda_worldcorpus_round7_manuscript_bibliography_enriched_v01.docx`
- `andromeda_worldcorpus_round7_manuscript_bibliography_enriched_v01.md`
- `andromeda_worldcorpus_round7_manuscript_bibliography_enriched_v01.pdf`
- `reference_matrix_round7.csv`
