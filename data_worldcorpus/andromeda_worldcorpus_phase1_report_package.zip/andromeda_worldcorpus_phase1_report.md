# Andromeda Nowicka — World Psychotherapy Corpus  
## Research report, Phase 1: corpus construction, keyword audit, title-pipeline transition, first exploratory analysis

**Date:** 19 May 2026  
**Research support agent:** Andromeda Nowicka v0.2  
**Human-in-the-loop controller / researcher:** Lech Kalita  
**Project status:** Phase 1 completed; corpus ready for title-based semantic refinement and round-2 analyses.

---

## 1. Executive summary

Phase 1 produced a large international bibliographic corpus of psychotherapy and clinical-psychology intervention journals for **2005–2025**. The initial aim was to build an author-keyword corpus using a Crossref → DOI landing-page → HTML keyword extraction pipeline. The bibliographic layer succeeded, but the author-keyword layer did not: a source audit found no consistent public landing-page metadata signal for author-assigned keywords.

The project therefore made an explicit methodological pivot: from **author-keyword analysis** to **title-based bibliometric discourse mapping**. This pivot was not arbitrary; it followed a documented audit showing that author keywords were not consistently exposed in public HTML metadata across the journal set.

After QA and cleaning, the current analytical corpus contains **14,229 titles** from **10 journals**, covering **2005–2025**. Round-1 exploratory analysis identified a discourse organized around outcome/change, anxiety, developmental populations, therapist training, depression, CBT, self/attachment, trauma/stress, emotion regulation, mechanisms, alliance/process, and assessment.

The corpus is now ready for Phase 2: audited title cleaning, stable term extraction, semantic family refinement, journal profiles, periodized trend interpretation, and manuscript-oriented reporting.

---

## 2. Research aim of Phase 1

The practical objective of Phase 1 was to determine whether a reproducible international psychotherapy corpus could be built from public bibliographic infrastructure and used for computational discourse mapping.

The initial plan had four linked goals:

1. Build a corpus across selected international psychotherapy and clinical psychology journals.
2. Retrieve bibliographic metadata and, where possible, author-assigned keywords.
3. Run QA before interpretation: counts, years, duplicate status, missingness and keyword coverage.
4. If author keywords were unavailable, identify a defensible alternative layer for thematic analysis.

The fourth goal became decisive. The project established that article titles, not author keywords, are the most stable common layer currently available from the harvested public metadata.

---

## 3. Journal selection rationale

The journal set was selected purposively rather than as a strict impact-factor ranking. The goal was to construct a broad yet coherent corpus covering major segments of international psychotherapy and clinical psychological intervention research.

The set included:

| Segment | Journals | Function in corpus |
|---|---|---|
| Core psychotherapy research and practice | *Psychotherapy Research*; *Psychotherapy* | Process, outcome, theory, practice and training |
| Clinical psychology intervention journals | *Journal of Consulting and Clinical Psychology*; *Clinical Psychology & Psychotherapy*; *Psychology and Psychotherapy: Theory, Research and Practice* | Treatment, diagnosis, intervention studies, clinical populations |
| CBT / behavioral clinical science | *Behaviour Research and Therapy*; *Cognitive Behaviour Therapy* | CBT, behavioral science, evidence-based treatments, mechanisms |
| Integration and counselling-practice link | *Journal of Psychotherapy Integration*; *Counselling and Psychotherapy Research* | Integrative psychotherapy and counselling/practice discourse |
| Creative/expressive therapies | *The Arts in Psychotherapy* | Arts-based and expressive psychotherapy traditions |

This design does not claim exhaustive representation of all psychotherapy journals. Important adjacent areas such as psychoanalysis, family therapy, group psychotherapy, body psychotherapy and implementation science may require dedicated supplementary corpora.

---

## 4. Phase 1 chronology and decision log

### 4.1 Initial scraper concept

The first technical concept was intentionally simple:

```text
Crossref as article index
→ DOI / landing page
→ public HTML metadata
→ article table + keyword-long table
→ QA
→ normalization
→ semantic mapping
```

This was attractive because it separated bibliographic discovery from publisher-specific archive scraping. Crossref supplied DOI-level article records; landing pages were then used as possible sources of keywords.

### 4.2 Early failure: zero records

The first execution returned zero landing pages for all journals. The failure occurred before landing-page parsing, at the Crossref query stage. The scraper was revised so that Crossref query diagnostics were logged explicitly.

### 4.3 Pagination failure: the “200 records” ceiling

The next successful run revealed a ceiling of approximately **200 records per journal**. This was traced to Crossref pagination: the scraper was effectively retrieving one page per ISSN, typically 100 records per ISSN, producing approximately 200 records per journal.

A later version switched to a more reliable offset-based pagination approach and added retries/timeouts. This allowed full retrieval.

### 4.4 Long full scrape

The full scrape ran overnight. The resulting raw bibliographic layer contained approximately **16,000 article records**, later consolidated into **15,979 unique article records** in the canonical title input.

### 4.5 Keyword failure and source audit

Despite successful bibliographic harvesting, the keyword-long tables contained zero usable keyword rows. A separate keyword source audit sampled landing pages across all journals. It found no consistent public metadata signal for author keywords: no stable `citation_keywords`, `dc.subject`, JSON-LD keywords, visible keyword section, or equivalent public HTML field.

This established that the keyword pipeline was not viable for this corpus unless additional external exports are obtained from sources such as PsycINFO, Scopus, Web of Science, publisher exports, or other licensed databases.

### 4.6 Methodological pivot

The project therefore pivoted to title-based analysis.

Decision:

```text
Do not continue author-keyword scraping from landing pages.
Treat the current corpus as a bibliographic/title corpus.
Use article titles as the primary comparable self-description layer.
Keep abstracts as a partial supplementary field only.
```

This was documented as a methodologically defensible change, not a failure of the project.

---

## 5. Data layers produced in Phase 1

The current data architecture is layered:

| Layer | Status | Interpretation |
|---|---|---|
| `raw_full_v05` | Immutable raw scrape | Source bibliographic layer |
| keyword-long files | Empty / non-usable | Negative result documenting keyword unavailability |
| keyword source audit | Completed | Confirms lack of stable public keyword signal |
| canonical title input | Completed | Clean bibliographic title corpus |
| analysis candidate | Completed | Technical/editorial records conservatively flagged |
| analysis v02 | Completed | Supplemental/supplementary material records removed |
| round-1 analysis outputs | Completed | Exploratory term/family/trend results |

Key principle: raw files should not be overwritten. Each transformation creates a new layer, with logs and summaries.

---

## 6. QA of the canonical title corpus

The uploaded canonical file `worldcorpus_titles_input.csv` was reviewed as the primary title-corpus input.

Core QA results:

| Measure | Value |
|---|---:|
| Rows | 15,979 |
| Journals | 10 |
| Year range | 2005–2025 |
| Unique `article_id` | 15,979 |
| Unique DOI | 15,979 |
| Duplicate `article_id` rows | 0 |
| Duplicate DOI rows | 0 |
| Missing titles | 0 |
| Missing years | 0 |
| Abstract coverage | 23.49% |
| Keyword rows | 0 |

This confirmed that the corpus is structurally clean as a title corpus.

---

## 7. Cleaning decisions before round-1 analysis

### 7.1 Removal of non-research/technical candidates

A rule-based QA screen flagged **1,081 records** as likely non-research or technical/editorial material. Examples included:

- `Book review`
- `Guide for Authors`
- `Notice`
- `Inside front cover`
- `Editorial board`
- `New Books of Potential Interest`
- `Correction`, `Corrigendum`, `Erratum`
- comments/replies/letters

After conservative exclusion, the first analysis-candidate corpus contained **14,898 records**.

### 7.2 Additional residual cleanup

A further residual pass removed **36 records** such as `Cover Design Credit` and similar front/back-matter artefacts.

### 7.3 Removal of supplemental material records

A major artefact was then identified: `Supplemental Material` / `Supplementary Material` titles. These were not substantive article titles and would falsely appear as a rising topic in later years.

Cleaning v02 removed:

| Cleaning step | Count |
|---|---:|
| Input analysis-candidate rows | 14,898 |
| Supplemental/supplementary material records removed | 669 |
| Retained in analysis v02 | 14,229 |

The current working corpus is therefore:

```text
worldcorpus_titles_analysis_v02.csv
n = 14,229
```

### 7.4 Review articles retained

A specific methodological decision was made to retain review articles. Reviews, meta-analyses and syntheses are treated as part of the visible discourse of the journals, not as technical noise.

---

## 8. Round-1 exploratory title analysis

Round-1 analysis was explicitly exploratory. It used document-frequency term extraction and rule-based thematic families. The families are probes, not final audited semantic categories.

Round-1 parameters:

| Measure | Value |
|---|---:|
| Titles analysed | 14,229 |
| Journals | 10 |
| Periods | 2005–2009; 2010–2014; 2015–2019; 2020–2025 |
| Terms with document frequency ≥ 10 | 2,345 |
| Rule-based thematic families | 26 |
| Titles assigned to ≥1 family | 11,624 |
| Share assigned to ≥1 family | 81.69% |

---

## 9. Main round-1 findings

### 9.1 Dominant thematic families

| Family | Titles | % of titles |
|---|---:|---:|
| outcome / change / recovery | 2,657 | 18.67% |
| anxiety / fear / phobia / panic | 1,697 | 11.93% |
| children / adolescents / youth | 1,644 | 11.55% |
| training / supervision / therapist development | 1,592 | 11.19% |
| depression and mood | 1,539 | 10.82% |
| CBT and cognitive-behavioral therapies | 1,337 | 9.40% |
| self / identity / attachment | 1,255 | 8.82% |
| trauma / PTSD / stress | 1,136 | 7.98% |
| emotion / regulation / affect | 1,069 | 7.51% |
| mechanisms / mediators / moderators | 989 | 6.95% |
| alliance / process / relationship | 955 | 6.71% |
| assessment / measurement / psychometrics | 806 | 5.66% |

The preliminary map shows a corpus strongly organized around outcome/change, common clinical conditions, developmental populations, therapist training, CBT, self/attachment, trauma/stress, emotion regulation, mechanisms, alliance/process and assessment.

### 9.2 Strongest rising families

| Family | Change from 2005–2009 to 2020–2025 |
|---|---:|
| review / meta-analysis / synthesis | +6.11 pp |
| third-wave / mindfulness / compassion | +5.24 pp |
| training / supervision / therapist development | +5.04 pp |
| digital / online / telehealth | +4.78 pp |
| outcome / change / recovery | +4.69 pp |
| COVID-19 / pandemic | +3.14 pp |
| emotion / regulation / affect | +2.79 pp |
| mechanisms / mediators / moderators | +2.67 pp |
| arts / creative therapies | +2.40 pp |
| alliance / process / relationship | +1.72 pp |

These trends suggest a shift toward synthesis/review work, third-wave and mindfulness/compassion approaches, therapist training/supervision, digital/online delivery, outcome/change discourse, COVID-era topics, emotion regulation, mechanisms/mediators/moderators, creative therapies, and alliance/process research.

---

## 10. Provisional interpretation

The initial title-based map suggests that international psychotherapy and clinical-psychology intervention discourse between 2005 and 2025 is structured by three overlapping axes.

### 10.1 Clinical-problem axis

Anxiety, depression, trauma/stress, personality/BPD, eating/body image, substance use and psychosis appear as core clinical problem categories. Anxiety and depression remain especially visible.

### 10.2 Treatment and process axis

CBT, outcome/change, alliance/process, mechanisms/mediators/moderators, assessment, therapist training and supervision form a treatment/process cluster. This suggests a field increasingly concerned not only with whether therapy works, but with how change is measured, mediated, delivered and supervised.

### 10.3 Expanding context axis

Digital/online therapy, third-wave/mindfulness/compassion, emotion regulation, culture/diversity/identity, COVID-19, and creative/arts therapies represent expansion zones. These do not replace the older clinical categories but add new vocabularies to the field.

---

## 11. Key limitations

1. **This is not a full-text discourse analysis.** Titles are compact indicators of article self-presentation, not substitutes for full article content.
2. **This is not an author-keyword analysis.** Author keywords were not retrievable from public landing-page metadata.
3. **Abstracts are incomplete.** Abstract coverage in the canonical corpus was approximately {summary_counts['abstract_coverage']}%, so abstracts should be treated as supplementary only unless enriched from additional sources.
4. **The journal sample is purposive.** It captures a broad comparative field but not the entire universe of psychotherapy journals.
5. **Rule-based families are provisional.** Round-1 families are exploratory probes and require semantic audit before manuscript-level interpretation.
6. **Title conventions vary by journal.** Some journals may use more descriptive, clinical or methodological title styles than others, influencing apparent thematic prominence.

---

## 12. Repository and workflow status

A repository-hygiene phase was initiated to separate project data from reusable Andromeda modules. The intended organization is:

```text
data_*                      project-specific corpora
modules/keywords_pipeline    reusable keyword workflow
modules/titles_pipeline      reusable title workflow
data_worldcorpus/            current international corpus
```

Two reusable module packages were created:

- keywords-pipeline: for corpora with available author keywords.
- titles-pipeline: for corpora where titles are the stable common metadata layer.

The current project should proceed using the title-pipeline.

---

## 13. Recommended Phase 2 tasks

Phase 2 should transform the exploratory round-1 map into a stable, auditable analytical result.

Recommended order:

1. Commit `worldcorpus_titles_analysis_v02.csv` as the current clean analytical input.
2. Commit round-1 outputs as exploratory, not final.
3. Audit and refine the rule-based family dictionary.
4. Create semantic consolidation tables for title terms.
5. Decide whether to keep broad families or introduce two-level coding:
   - fine-grained title concepts,
   - broader thematic families.
6. Produce journal-specific profiles.
7. Produce periodized trend tables using percentages rather than raw counts.
8. Build a co-occurrence network of audited thematic families.
9. Draft a methods section describing the pivot from keywords to titles.
10. Draft a results section around:
   - dominant families,
   - rising discourses,
   - journal profiles,
   - field-level interpretation.

---

## 14. Suggested methods wording

> The corpus was initially designed as an author-keyword bibliometric dataset. Articles were identified through DOI-level bibliographic metadata and journal landing pages were audited for publicly exposed keyword metadata. Because author-assigned keywords were not consistently available in public landing-page HTML or metadata, the analysis was transferred to a title-based pipeline. Article titles were treated as standardized, consistently available indicators of article self-presentation. The analysis therefore maps title-level discourse rather than full-text content or author-keyword taxonomies.

---

## 15. Suggested acknowledgment

Bibliometric data preparation and semantic normalization were supported by the research agent Andromeda Nowicka (v0.2), a human-in-the-loop computational bibliometrics system developed under the supervision of Lech Kalita.

Formal reference if needed:

Andromeda Nowicka (v0.2). HITL bibliometric analysis agent for discourse mapping. Controller: Lech Kalita. DID: did:web:kalitalech-hash.github.io:andromeda.

---

## 16. Phase 1 conclusion

Phase 1 achieved the most important objective: it produced a large, auditable international psychotherapy corpus and established the correct analytical layer for this dataset. The failure to retrieve author keywords was converted into a documented methodological decision. The resulting title corpus is coherent, clean enough for analysis, and already yields interpretable patterns.

The project is now positioned as:

```text
A title-based longitudinal bibliometric discourse map
of international psychotherapy and clinical psychology intervention research,
2005–2025.
```

This is a strong and defensible basis for Phase 2.
