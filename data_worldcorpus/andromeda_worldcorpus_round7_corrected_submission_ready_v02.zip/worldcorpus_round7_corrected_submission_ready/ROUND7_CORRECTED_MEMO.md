# Round 7 corrected submission-ready manuscript v02

## Correction

This version uses the Round 6 manuscript as the base text and preserves its structure, argument, tables, figures, and overall quality.

The Round 7 bibliography was retained, but the bibliography was integrated into the manuscript by adding targeted in-text citations in the existing Round 6 prose rather than rewriting the manuscript.

## What changed relative to Round 6

- Expanded in-text references in Introduction, Methods, Discussion, and Limitations.
- Replaced the short Round 6 reference list with the enriched 30-item Round 7 bibliography.
- Preserved the Round 6 manuscript structure and wording as far as possible.
- Preserved Round 6 tables and figures.
- Rendered DOCX to PDF for layout QA.

## What was not changed

- No new analyses were added.
- No results were altered.
- No tables or figures were substantively changed.
- No reinterpretation of findings was introduced.

## Status

Submission-ready working draft for further author review and final journal formatting.
