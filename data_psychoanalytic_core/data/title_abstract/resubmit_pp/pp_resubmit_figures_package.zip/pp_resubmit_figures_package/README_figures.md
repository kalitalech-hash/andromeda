# Psychoanalytic Psychology resubmission figures package

This package contains the figure files embedded in the revised Results-to-end DOCX.

## Figures

- `figure_1_pd_exclusion_core_coverage.png`  
  Full corpus vs excluding Psychoanalytic Dialogues: drive/conflict/defense and relational/intersubjective coverage by period.

- `figure_2_pd_exclusion_indices.png`  
  Full corpus vs excluding Psychoanalytic Dialogues: relational shift, contextualization, and narrative reframing indices by period.

- `figure_3_historical_threshold_relational.png`  
  Relational language: lexical occurrence versus post-1990 school-signaling interpretation.

- `figure_4_journal_period_composition.png`  
  Journal-period composition of the ART analytical corpus.

- `figure_5_within_journal_changes.png`  
  Within-journal first-to-last changes in core semantic indices.

- `figure_6_global_coverage.png`  
  Refined global coverage of semantic families.

## Data sources

The `data_sources/` folder contains the CSV files used locally to regenerate these figures for the draft:
`pd_sensitivity.csv`, `threshold.csv`, `composition.csv`, `within.csv`, `coverage.csv`, `period_table.csv`, and `direction.csv`.

## Note

These files are intended as the manuscript figure layer for the Psychoanalytic Psychology resubmission draft.
